RIZERIE SERVICE PRO V2.7 — ANDROID QR (source seulement)

Contenu:
- android/ : projet Android Java + WebView, icone officielle, scanner QR.
- tests/sync_correction_mobile.test.js : test du noyau de synchronisation (Node.js).
- GITHUB_BUILD_APK_ANDROID_QR.yml : configuration GitHub Actions.

Compilation: envoyer ce ZIP inchangé à la racine du repository GitHub,
creer .github/workflows/build-apk.yml et y coller le contenu de
GITHUB_BUILD_APK_ANDROID_QR.yml. Lancer manuellement le workflow depuis Actions.

Le QR sert uniquement à appairer et verifier le PC sur le Wi-Fi local.
AUCUN transfert de donnees n'est demarre par le scan QR. Le transfert Wi-Fi direct
bidirectionnel reste a developper. Les exports/imports .rpsync existants restent presents.
Tests complets sur appareils et compilation APK non effectues ici.
Usage beta de test uniquement. Faire une sauvegarde des donnees avant mise a jour.
