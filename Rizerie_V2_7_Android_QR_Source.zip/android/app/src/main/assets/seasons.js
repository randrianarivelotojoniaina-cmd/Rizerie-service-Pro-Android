'use strict';
/* Rizerie Service Pro V2.3 — Saisons par rizerie. Dates ISO locales (YYYY-MM-DD). */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.RizerieSeasons=api;})(typeof window!=='undefined'?window:null,function(){
 const ISO=/^\d{4}-\d{2}-\d{2}$/;
 function validDate(d){if(typeof d!=='string'||!ISO.test(d))return false;const t=new Date(d+'T12:00:00Z');return !Number.isNaN(t.valueOf())&&t.toISOString().slice(0,10)===d;}
 function nextDay(d){if(!validDate(d))throw Error('Date incorrecte');const t=new Date(d+'T12:00:00Z');t.setUTCDate(t.getUTCDate()+1);return t.toISOString().slice(0,10);}
 function prevDay(d){if(!validDate(d))throw Error('Date incorrecte');const t=new Date(d+'T12:00:00Z');t.setUTCDate(t.getUTCDate()-1);return t.toISOString().slice(0,10);}
 function iso(d){const x=String(d||'').slice(0,10);return validDate(x)?x:null;}
 function siteOperations(s,siteId){const events=[];
  for(const p of s.prestations||[])if(p.siteId===siteId)events.push(p);
  for(const r of s.readings||[])if(r.siteId===siteId)events.push(r);
  for(const v of s.sales||[])if(v.siteId===siteId)events.push(v);
  for(const v of s.consumptions||[])if(v.siteId===siteId)events.push(v);
  for(const p of s.payments||[])if((s.employees||[]).find(e=>e.id===p.employeeId)?.siteId===siteId)events.push(p);
  for(const m of s.movements||[])if(m.siteId===siteId)events.push(m);
  return events;
 }
 function earliestSiteActivity(s,siteId){const all=siteOperations(s,siteId).map(x=>iso(x.date)).filter(Boolean).sort();return all[0]||null;}
 function ensureSeasons(s,today){if(!Array.isArray(s.seasons))s.seasons=[];if(!Number.isSafeInteger(s.nextSeason)||s.nextSeason<1)s.nextSeason=1;
  const ids=new Set(s.seasons.map(x=>x.id));for(const site of s.sites||[]){if(s.seasons.some(x=>x.siteId===site.id))continue;
   const activity=earliestSiteActivity(s,site.id),hadStart=!!iso(site.startDate),start=activity||iso(site.startDate)||today;
   if(!validDate(start))throw Error('Date de démarrage indisponible pour '+site.name);
   site.startDate=site.startDate||start;
   let id;do{id='ss'+s.nextSeason++}while(ids.has(id));ids.add(id);
   s.seasons.push({id,siteId:site.id,number:1,start,end:null,status:'active',inferred:!hadStart||!!activity&&activity<site.startDate,createdAt:new Date().toISOString()});
  }
  return s;
 }
 function bySite(s,siteId){return(s.seasons||[]).filter(x=>x.siteId===siteId).slice().sort((a,b)=>a.number-b.number)}
 function seasonOn(s,siteId,date){const d=iso(date);if(!d)return null;return bySite(s,siteId).find(x=>d>=x.start&&(!x.end||d<=x.end))||null;}
 function active(s,siteId){return bySite(s,siteId).find(x=>x.status==='active')||null;}
 function createFirst(s,siteId,start){if(!validDate(start))throw Error('Date initiale incorrecte');if(bySite(s,siteId).length)throw Error('Saison initiale déjà créée');if(!Array.isArray(s.seasons))s.seasons=[];if(!Number.isSafeInteger(s.nextSeason))s.nextSeason=1;
  const o={id:'ss'+s.nextSeason++,siteId,number:1,start,end:null,status:'active',inferred:false,createdAt:new Date().toISOString()};s.seasons.push(o);return o;}
 function close(s,siteId,end){const a=active(s,siteId);if(!a)throw Error('Aucune saison active');if(!validDate(end)||end<a.start)throw Error('Date de clôture antérieure au début');const future=siteOperations(s,siteId).some(x=>{const d=iso(x.date);return d&&d>end});if(future)throw Error('Des opérations existent après la date de clôture');
  // Un relevé est nécessaire lorsque le tonnage de la saison n'est pas encore couvert.
  const ps=(s.prestations||[]).filter(x=>x.siteId===siteId&&iso(x.date)>=a.start&&iso(x.date)<=end);
  const readings=(s.readings||[]).filter(x=>x.siteId===siteId&&iso(x.date)>=a.start&&iso(x.date)<=end);
  if(ps.length){if(!readings.length)throw Error('Relevé gasoil de fin de saison nécessaire avant clôture');
   const covered=readings.reduce((t,x)=>t+Number(x.paddy||0),0),kg=ps.reduce((t,x)=>t+Number(x.kg||0),0);
   if(Math.abs(kg-covered)>0.03)throw Error('Paddy non couvert par relevé gasoil : clôture refusée');
  }
  a.end=end;a.status='closed';a.closedAt=new Date().toISOString();return a;
 }
 function open(s,siteId,start){const previous=bySite(s,siteId),last=previous[previous.length-1];if(!last||last.status!=='closed')throw Error('Clôturez la saison précédente avant ouverture');if(!validDate(start)||start<=last.end)throw Error('Nouvelle saison doit commencer après clôture');
  const expected=nextDay(last.end);if(start!==expected)throw Error('Pour éviter une période sans saison, la date de début doit être '+expected);
  const o={id:'ss'+s.nextSeason++,siteId,number:last.number+1,start,end:null,status:'active',inferred:false,createdAt:new Date().toISOString()};s.seasons.push(o);return o;
 }
 function validateSeasons(s){if(!Array.isArray(s.seasons)||!Number.isSafeInteger(s.nextSeason)||s.nextSeason<1)throw Error('Structure saisons invalide');
  const ids=new Set();for(const site of s.sites||[]){const seasons=bySite(s,site.id);if(!seasons.length)throw Error('Saison manquante pour '+site.name);let activeCount=0;
   for(let i=0;i<seasons.length;i++){const a=seasons[i];if(ids.has(a.id))throw Error('Identifiant saison en double');ids.add(a.id);
    if(a.number!==i+1||!validDate(a.start)||a.end!==null&&!validDate(a.end)||a.end&&a.end<a.start||!['active','closed'].includes(a.status))throw Error('Saison invalide');
    if(a.status==='closed'&&!a.end||a.status==='active'&&a.end)throw Error('Statut saison incohérent');
    if(a.status==='active')activeCount++;
    if(i>0){const prior=seasons[i-1];if(prior.status!=='closed'||nextDay(prior.end)!==a.start)throw Error('Saisons chevauchantes ou lacune');}
   }
   if(activeCount>1||activeCount===1&&seasons.at(-1).status!=='active')throw Error('Plusieurs saisons actives');
  }
  if(s.seasons.some(x=>!(s.sites||[]).some(y=>y.id===x.siteId)))throw Error('Saison liée à rizerie inexistante');
 }
 function validateSeasonChanges(old,now){const oldSeasons=old.seasons||[];const recent=now.seasons||[];
  for(const s of oldSeasons){const x=recent.find(z=>z.id===s.id);if(!x)throw Error('Historique saison supprimé');
   if(s.siteId!==x.siteId||s.start!==x.start||s.number!==x.number||s.inferred!==x.inferred)throw Error('Historique saison modifié');
   if(s.status==='closed'&&(x.status!=='closed'||x.end!==s.end))throw Error('Saison clôturée non modifiable');
   if(s.status==='active'&&x.status==='closed'&&(!x.end||x.end<x.start))throw Error('Clôture incorrecte');
  }
  for(const kind of ['prestations','sales','consumptions','readings','payments','movements']){
   const before=old[kind]||[],after=now[kind]||[];
   const newItems=kind==='movements'?after.slice(0,Math.max(0,after.length-before.length)):after.slice(before.length);
   for(const item of newItems){let siteId=item.siteId;
    if(!siteId&&kind==='sales')siteId=now.magasins.find(m=>m.id===item.magId)?.siteId;
    if(!siteId&&kind==='payments')siteId=now.employees.find(e=>e.id===item.employeeId)?.siteId;
    if(!siteId)continue;
    const d=iso(item.date);if(!d)continue;
    const seas=seasonOn(now,siteId,d);if(!seas||seas.status==='closed')throw Error('Opération dans une saison clôturée ou hors période : '+kind);
   }
  }
 }
 return{validDate,nextDay,prevDay,iso,ensureSeasons,earliestSiteActivity,bySite,seasonOn,active,createFirst,close,open,validateSeasons,validateSeasonChanges};
});
