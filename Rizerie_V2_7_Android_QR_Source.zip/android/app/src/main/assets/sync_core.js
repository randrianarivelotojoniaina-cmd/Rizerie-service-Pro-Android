'use strict';
/* Rizerie Service Pro Sync V2.5: deterministic journal deltas and conflict review.
   Designed for offline devices; a duplicate fingerprint is a warning, never a proof. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.RizerieSyncCore=api;})(typeof window!=='undefined'?window:null,function(){
const ARRAYS=['articles','sites','magasins','caisses','prestations','movements','tarifHistory','readings','sales','consumptions','employees','attendance','payments','purchaseOrders','openingStocks','seasons'];
const APPEND_ONLY=new Set(['prestations','readings','sales','consumptions','payments','openingStocks','tarifHistory']);
const obj=x=>x&&typeof x==='object'&&!Array.isArray(x);
const copy=x=>JSON.parse(JSON.stringify(x));
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
function stripSyncMeta(x){const v=copy(x);if(obj(v)){delete v.syncEventId;delete v.syncDeviceId;}return v;}
function key(item){return item?.id!=null?'id:'+item.id:item?.ref!=null?'ref:'+item.ref:null}
const number=x=>typeof x==='number'&&Number.isFinite(x)?x:0;
function mapRows(rows){const m=new Map();for(const [i,r] of rows.entries()){const k=key(r)||'pos:'+i;if(m.has(k))throw Error('Identifiant doublé dans collection : '+k);m.set(k,r);}return m}
function diff(before,after){
 const changes={created:{},updated:{},values:{},counters:{},extra:{}};
 for(const k of ARRAYS){
  const aa=before[k]||[],bb=after[k]||[],m=mapRows(aa),n=mapRows(bb),created=[],updated=[];
  for(const [id,r] of m)if(!n.has(id))throw Error('Suppression locale non supportée pour synchronisation : '+k+' '+id);
  for(const [id,r] of n){if(!m.has(id))created.push(copy(r));else if(!same(r,m.get(id)))updated.push({id,before:copy(m.get(id)),after:copy(r)});}
  if(created.length)changes.created[k]=created;
  if(updated.length)changes.updated[k]=updated;
 }
 // Allow concurrent operations on the same accounts: merge ADDITIVE differences, never replace balances.
 for(const k of ['stocks','stockValues']){
  const deltas=[];const allM=new Set([...Object.keys(before[k]||{}),...Object.keys(after[k]||{})]);
  for(const m of allM){const x=before[k]?.[m]||{},y=after[k]?.[m]||{};for(const a of new Set([...Object.keys(x),...Object.keys(y)])){
   const previous=x[a],next=y[a];if(same(previous,next))continue;
   if(previous===null||next===null)throw Error('Valeur stock inconnue à résoudre sur PC : '+m+'/'+a);
   if(next!==undefined&&(!Number.isFinite(next)||next<0))throw Error('Stock/valeur invalide');
   deltas.push({mag:m,article:a,delta:number(next)-number(previous)});
  }}if(deltas.length)changes.values[k]=deltas;
 }
 const oldC=new Map((before.caisses||[]).map(c=>[c.id,c]));
 changes.values.balances=[];
 for(const c of after.caisses||[]){const b=oldC.get(c.id);if(b&&c.solde!==b.solde)changes.values.balances.push({caisse:c.id,delta:c.solde-b.solde});}
 // remove 'solde' from ordinary updates, because balance is additive, and order of two devices is arbitrary.
 if(changes.updated.caisses){changes.updated.caisses=changes.updated.caisses.map(u=>({id:u.id,before:{...u.before,solde:0},after:{...u.after,solde:0}})).filter(u=>!same(u.before,u.after));if(!changes.updated.caisses.length)delete changes.updated.caisses;}
 for(const [k,v] of Object.entries(after)){
  if(k.startsWith('next')&&Number.isSafeInteger(v))changes.counters[k]=v;
  else if(!ARRAYS.includes(k)&&!['stocks','stockValues'].includes(k)&&!k.startsWith('next')&&!same(before[k],v)){
    if(['exerciseYear','yearOpenedAt'].includes(k))throw Error('Changement exercice non importable depuis Android');
    changes.extra[k]={before:copy(before[k]??null),after:copy(v??null)};
  }
 }
 if(!Object.keys(changes.created).length&&!Object.keys(changes.updated).length&&!Object.keys(changes.values).some(k=>changes.values[k].length)&&!Object.keys(changes.extra).length)return null;
 return changes;
}
function apply(state,event){
 const c=event.changes;if(!obj(c))throw Error('Événement sans changements');
 const s=copy(state);
 const newRefs=new Set((s.movements||[]).map(x=>x.ref));
 for(const [k,items] of Object.entries(c.created||{})){
  if(!ARRAYS.includes(k)||!Array.isArray(items))throw Error('Collection interdite '+k);
  s[k]??=[];
  for(const raw of items){let item=copy(raw);let id=key(item);
   if(k==='movements'){
    // The per-device MVT-xxxxx can collide. Allocate a canonical PC ref on import.
    if(newRefs.has(item.ref)){
      item.mobileRef=item.ref;
      do{item.ref='MVT-'+String(s.nextOperation++).padStart(5,'0');}while(newRefs.has(item.ref));
    }
    newRefs.add(item.ref);
   }
   if(k!=='movements'&&key(item)&&s[k].some(r=>key(r)===id))throw Error('Conflit identifiant '+k+' '+id);
   item.syncEventId=event.id;item.syncDeviceId=event.deviceId;
   if(k==='movements')s[k].unshift(item);else s[k].push(item);
  }
 }
 for(const [k,updates] of Object.entries(c.updated||{})){
  if(!ARRAYS.includes(k)||!Array.isArray(updates))throw Error('Modification non autorisée '+k);
  for(const u of updates){const found=(s[k]||[]).findIndex(r=>key(r)===u.id);if(found<0)throw Error('Référentiel absent : '+k+' '+u.id);
   let actual=copy(s[k][found]);if(k==='caisses')actual.solde=0;
   if(!same(stripSyncMeta(actual),stripSyncMeta(u.before)))throw Error('Modification concurrente : '+k+' '+u.id);
   const next=copy(u.after);if(s[k][found].syncEventId){next.syncEventId=s[k][found].syncEventId;next.syncDeviceId=s[k][found].syncDeviceId;}if(k==='caisses')next.solde=s[k][found].solde;
   s[k][found]=next;
  }
 }
 for(const k of ['stocks','stockValues'])for(const v of c.values?.[k]||[]){
   if(!s.magasins.some(x=>x.id===v.mag)||!s.articles.some(x=>x.id===v.article))throw Error('Magasin/article inconnu pour stock');
   s[k]??={};s[k][v.mag]??={};const a=number(s[k][v.mag][v.article])+v.delta;
   if(!Number.isFinite(a)||a< -0.00001)throw Error('Stock ou valeur négatif après consolidation : '+k+' '+v.mag+'/'+v.article);
   s[k][v.mag][v.article]=Math.round(a*1000000)/1000000;
 }
 for(const v of c.values?.balances||[]){const caisse=s.caisses.find(x=>x.id===v.caisse);if(!caisse)throw Error('Caisse absente');const a=number(caisse.solde)+v.delta;
   if(!Number.isFinite(a)||a< -0.00001)throw Error('Solde caisse négatif après consolidation : '+caisse.name);
   caisse.solde=Math.round(a*1000000)/1000000;
 }
 for(const [k,v] of Object.entries(c.extra||{})){if(!same(s[k]??null,v.before))throw Error('Conflit champ '+k);s[k]=copy(v.after)}
 for(const [k,v] of Object.entries(c.counters||{}))if(Number.isSafeInteger(v))s[k]=Math.max(number(s[k]),v);
 // Original refs must remain unique after canonical allocation; never rewrite already validated operations.
 const mvRefs=(s.movements||[]).map(m=>m.ref);if(new Set(mvRefs).size!==mvRefs.length)throw Error('Références mouvements non uniques');
 s.nextOperation=Math.max(number(s.nextOperation),1,...mvRefs.map(r=>Number(String(r).match(/^MVT-(\d+)$/)?.[1]||0)+1));
 return s;
}
function suspicious(event,state){
 const existing=state.movements||[],out=[];for(const raw of event.changes?.created?.movements||[]){
  for(const m of existing){if(m.syncEventId===event.id)continue;
   const aa=raw.amount??null,bb=m.amount??null,qa=raw.quantity??null,qb=m.quantity??null;
   if(String(raw.type)!==String(m.type)||String(raw.date).slice(0,10)!==String(m.date).slice(0,10))continue;
   if((raw.siteId||null)!==(m.siteId||null)||(raw.articleId||null)!==(m.articleId||null))continue;
   if((raw.cashSourceId||null)!==(m.cashSourceId||null)||(raw.cashDestId||null)!==(m.cashDestId||null))continue;
   if((raw.magSourceId||null)!==(m.magSourceId||null)||(raw.magDestId||null)!==(m.magDestId||null))continue;
   if((aa===null||bb===null)&&(qa===null||qb===null))continue;
   if(aa!==null&&bb!==null&&Math.abs(aa-bb)>0.0001)continue;
   if(qa!==null&&qb!==null&&Math.abs(qa-qb)>0.0001)continue;
   out.push({mobileRef:raw.ref,existingRef:m.ref,type:m.type,date:String(raw.date).slice(0,10),amount:aa,quantity:qa,siteId:raw.siteId??null});
  }
 }
 return out;
}
// An event UUID protects against technical re-import; an unchanged business row ID
// indicates a correction, never a fresh operation. Do not guess from dates alone.
function classify(event){
 const c=event?.changes||{};
 const created=Object.fromEntries(Object.entries(c.created||{}).map(([k,v])=>[k,v.length]).filter(([,n])=>n));
 const updated=Object.fromEntries(Object.entries(c.updated||{}).map(([k,v])=>[k,v.length]).filter(([,n])=>n));
 return {created,updated,isCorrection:Object.keys(updated).length>0,
         isCreation:Object.keys(created).length>0,
         eventId:event?.id||null,deviceId:event?.deviceId||null};
}
return {diff,apply,suspicious,classify,version:2};
});
