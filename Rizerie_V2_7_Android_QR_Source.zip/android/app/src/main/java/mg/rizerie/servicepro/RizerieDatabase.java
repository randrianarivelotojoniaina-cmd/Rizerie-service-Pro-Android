package mg.rizerie.servicepro;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.UUID;

final class RizerieDatabase extends SQLiteOpenHelper {
  private final Context context;
  RizerieDatabase(Context c){super(c,"rizerie_mobile.sqlite3",null,1);context=c.getApplicationContext();}
  @Override public void onCreate(SQLiteDatabase db){
    db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY,v TEXT NOT NULL)");
    db.execSQL("CREATE TABLE state(id INTEGER PRIMARY KEY CHECK(id=1),rev INTEGER NOT NULL,payload TEXT NOT NULL)");
    db.execSQL("CREATE TABLE outbox(event_id TEXT PRIMARY KEY,device_id TEXT NOT NULL,created_at TEXT NOT NULL,payload TEXT NOT NULL)");
    db.execSQL("CREATE TABLE admin(id INTEGER PRIMARY KEY CHECK(id=1),salt TEXT NOT NULL,hash TEXT NOT NULL)");
    try(InputStream i=context.getAssets().open("default_state.json")){
      byte[] data=new byte[0];java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] chunk=new byte[2048];int n;while((n=i.read(chunk))!=-1)out.write(chunk,0,n);
      data=out.toByteArray();
      db.execSQL("INSERT INTO state(id,rev,payload) VALUES(1,0,?)",new Object[]{new String(data,StandardCharsets.UTF_8)});
    }catch(Exception ex){throw new IllegalStateException("Initialisation base impossible",ex);}
    db.execSQL("INSERT INTO meta(k,v) VALUES('deviceId',?)",new Object[]{"android_"+UUID.randomUUID().toString().replace("-","")});
  }
  @Override public void onUpgrade(SQLiteDatabase db,int a,int b){throw new IllegalStateException("Migration de base à valider");}
  String deviceId(){try(Cursor c=getReadableDatabase().rawQuery("SELECT v FROM meta WHERE k='deviceId'",null)){c.moveToFirst();return c.getString(0);}}
  JSONObject state() throws Exception {try(Cursor c=getReadableDatabase().rawQuery("SELECT rev,payload FROM state WHERE id=1",null)){c.moveToFirst();return new JSONObject().put("ok",true).put("revision",c.getInt(0)).put("data",new JSONObject(c.getString(1)));}}
  boolean configured(){try(Cursor c=getReadableDatabase().rawQuery("SELECT count(1) FROM admin",null)){c.moveToFirst();return c.getLong(0)>0;}}
  static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(java.util.Locale.ROOT,"%02x",x&255));return s.toString();}
  static String pwhash(String pass,String salt) throws Exception {byte[] s=new byte[salt.length()/2];for(int i=0;i<s.length;i++)s[i]=(byte)Integer.parseInt(salt.substring(2*i,2*i+2),16);javax.crypto.spec.PBEKeySpec k=new javax.crypto.spec.PBEKeySpec(pass.toCharArray(),s,310000,256);return hex(javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(k).getEncoded());}
  JSONObject setup(JSONObject args) throws Exception {
    if(configured())throw new Exception("Compte déjà créé");String pass=args.getString("password");if(pass.length()<10||!pass.equals(args.getString("confirm")))throw new Exception("Mot de passe de 10 caractères minimum et confirmation identique requis");
    byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);getWritableDatabase().execSQL("INSERT INTO admin(id,salt,hash) VALUES(1,?,?)",new Object[]{hex(salt),pwhash(pass,hex(salt))});return new JSONObject().put("ok",true);
  }
  JSONObject login(JSONObject args) throws Exception{
    String hash,salt;try(Cursor c=getReadableDatabase().rawQuery("SELECT salt,hash FROM admin WHERE id=1",null)){if(!c.moveToFirst())throw new Exception("Compte non créé");salt=c.getString(0);hash=c.getString(1);}
    if(!MessageDigest.isEqual(hash.getBytes(StandardCharsets.US_ASCII),pwhash(args.optString("password"),salt).getBytes(StandardCharsets.US_ASCII)))throw new Exception("Mot de passe incorrect");
    return new JSONObject().put("ok",true);
  }
  JSONObject save(JSONObject args) throws Exception{
    SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
      int rev;try(Cursor c=db.rawQuery("SELECT rev FROM state WHERE id=1",null)){c.moveToFirst();rev=c.getInt(0);}
      if(rev!=args.getInt("revision"))throw new Exception("Conflit de révision");
      JSONObject data=args.getJSONObject("data");
      // Native minimum checks; additional global validation is applied by Desktop on import.
      for(int i=0;i<data.getJSONArray("caisses").length();i++)if(data.getJSONArray("caisses").getJSONObject(i).optDouble("solde",-1)<0)throw new Exception("Solde caisse négatif");
      JSONObject stocks=data.getJSONObject("stocks");for(java.util.Iterator<String> mi=stocks.keys();mi.hasNext();){JSONObject s=stocks.getJSONObject(mi.next());for(java.util.Iterator<String> ai=s.keys();ai.hasNext();)if(s.optDouble(ai.next(),-1)<0)throw new Exception("Stock négatif");}
      db.execSQL("UPDATE state SET rev=?,payload=? WHERE id=1 AND rev=?",new Object[]{rev+1,data.toString(),rev});
      if(args.has("event")&&!args.isNull("event")){
        JSONObject event=args.getJSONObject("event");db.execSQL("INSERT INTO outbox(event_id,device_id,created_at,payload) VALUES(?,?,?,?)",new Object[]{event.getString("id"),deviceId(),event.getString("createdAt"),event.toString()});
      }
      db.setTransactionSuccessful();return new JSONObject().put("ok",true).put("revision",rev+1);
    }finally{db.endTransaction();}
  }
  JSONObject events() throws Exception {
    JSONArray list=new JSONArray();try(Cursor c=getReadableDatabase().rawQuery("SELECT payload FROM outbox ORDER BY created_at,event_id",null)){while(c.moveToNext())list.put(new JSONObject(c.getString(0)));}
    return new JSONObject().put("product","Rizerie Service Pro").put("format",1).put("kind","mobile-events").put("deviceId",deviceId()).put("createdAt",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",java.util.Locale.ROOT).format(new java.util.Date())).put("events",list);
  }
  int pending(){try(Cursor c=getReadableDatabase().rawQuery("SELECT count(1) FROM outbox",null)){c.moveToFirst();return c.getInt(0);}}
  JSONObject importMaster(JSONObject data) throws Exception {
    if(!"Rizerie Service Pro".equals(data.getString("product"))||data.getInt("format")!=1||!"pc-snapshot".equals(data.getString("kind")))throw new Exception("Fichier PC invalide");
    JSONObject st=data.getJSONObject("state");
    if(!st.has("articles")||!st.has("caisses")||!st.has("stocks")||!st.has("movements"))throw new Exception("Base PC incomplète");
    JSONArray acknowledged=data.optJSONArray("ackEventIds");java.util.HashSet<String> done=new java.util.HashSet<>();if(acknowledged!=null)for(int i=0;i<acknowledged.length();i++)done.add(acknowledged.getString(i));
    SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
      if(!done.isEmpty()){for(String id:done)db.execSQL("DELETE FROM outbox WHERE event_id=?",new Object[]{id});}
      int remaining;try(Cursor c=db.rawQuery("SELECT count(1) FROM outbox",null)){c.moveToFirst();remaining=c.getInt(0);}
      if(remaining>0)throw new Exception(remaining+" opérations Android non synchronisées. Transférez-les au PC avant de charger une nouvelle base.");
      db.execSQL("UPDATE state SET rev=rev+1,payload=? WHERE id=1",new Object[]{st.toString()});db.setTransactionSuccessful();return new JSONObject().put("ok",true).put("acknowledged",done.size());
    }finally{db.endTransaction();}
  }
}
