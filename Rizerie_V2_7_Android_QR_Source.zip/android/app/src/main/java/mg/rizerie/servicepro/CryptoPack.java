package mg.rizerie.servicepro;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONObject;

public class CryptoPack {
    private static final int ROUNDS=150000;
    private static final byte[] AAD="Rizerie-Service-Pro-rpsync-v1".getBytes(StandardCharsets.UTF_8);
    static byte[] key(String pass,byte[] salt) throws Exception {
        if(pass==null || pass.length()<10)throw new Exception("Code de synchronisation : 10 caractères minimum");
        PBEKeySpec spec=new PBEKeySpec(pass.toCharArray(),salt,ROUNDS,256);
        try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}
        finally{spec.clearPassword();}
    }
    public static String encrypt(JSONObject payload,String pass) throws Exception {
        SecureRandom random=new SecureRandom();byte[] salt=new byte[16],iv=new byte[12];random.nextBytes(salt);random.nextBytes(iv);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key(pass,salt),"AES"),new GCMParameterSpec(128,iv));c.updateAAD(AAD);
        byte[] encrypted=c.doFinal(payload.toString().getBytes(StandardCharsets.UTF_8));
        return new JSONObject().put("format","rpsync-encrypted").put("v",1).put("iterations",ROUNDS).put("salt",Base64.getEncoder().encodeToString(salt)).put("iv",Base64.getEncoder().encodeToString(iv)).put("ciphertext",Base64.getEncoder().encodeToString(encrypted)).toString();
    }
    public static JSONObject decrypt(String text,String pass) throws Exception {
        JSONObject pack=new JSONObject(text);
        if(!"rpsync-encrypted".equals(pack.getString("format"))||pack.getInt("v")!=1||pack.getInt("iterations")!=ROUNDS)throw new Exception("Format incompatible");
        byte[] salt=Base64.getDecoder().decode(pack.getString("salt")),iv=Base64.getDecoder().decode(pack.getString("iv")),bytes=Base64.getDecoder().decode(pack.getString("ciphertext"));
        if(salt.length!=16||iv.length!=12||bytes.length<17||bytes.length>24000000)throw new Exception("Paquet invalide");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key(pass,salt),"AES"),new GCMParameterSpec(128,iv));c.updateAAD(AAD);
        return new JSONObject(new String(c.doFinal(bytes),StandardCharsets.UTF_8));
    }
}
