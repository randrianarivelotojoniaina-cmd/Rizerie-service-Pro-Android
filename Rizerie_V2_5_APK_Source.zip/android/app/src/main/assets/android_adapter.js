'use strict';
/* Native Android SQLite: identical synchronous API to Electron's context bridge.
   All 11 existing modules reuse the original index.html, with native local storage.
   Each successfully saved transaction creates an independent UUID journal event. */
(function(){
 const rpc=(op,a={})=>JSON.parse(AndroidRizerie.call(op,JSON.stringify(a)));
 let last=null;
 window.rizerieDesktop=Object.freeze({
  isConfigured:()=>rpc('configured'),
  createAdmin:(password,confirm)=>rpc('setup',{password,confirm}),
  login:password=>rpc('login',{password}),
  logout:()=>rpc('logout'),
  state:()=>{const r=rpc('state');if(r.ok)last=structuredClone(r.data);return r;},
  saveState:body=>{
   try{
    if(!last)throw Error('La base locale est indisponible');
    const changes=RizerieSyncCore.diff(last,body.data);
    const device=rpc('device');if(!device.ok)throw Error(device.error);
    const event=changes?{id:rpc('uuid').id,deviceId:device.deviceId,createdAt:new Date().toISOString(),changes}:null;
    if(event){const similarities=RizerieSyncCore.suspicious(event,last);
      if(similarities.length){const line=similarities.slice(0,3).map(x=>`${x.type} · ${x.date} · ${x.amount??x.quantity}`).join('\n');
        if(!confirm(`Doublon possible (${similarities.length}) :\n${line}\n\nANNULER : bloquer la saisie.\nOK : confirmer une opération distincte.`))return {ok:false,error:'Enregistrement annulé après alerte doublon'};
        event.localConfirmedDistinct=true;
      }
    }
    const r=rpc('save',{revision:body.revision,data:body.data,event});
    if(r.ok)last=structuredClone(body.data);
    return r;
   }catch(ex){return {ok:false,error:String(ex.message)};}
  },
  annualArchives:()=>({ok:true,archives:[]}),
  annualPreview:()=>({ok:false,error:'Clôture annuelle réservée au PC principal'}),
  annualClose:()=>({ok:false,error:'Clôture annuelle réservée au PC principal'}),
  verifyAnnualArchive:()=>({ok:false,error:'Archives consultables sur PC uniquement'}),
  restoreAnnualArchive:()=>({ok:false,error:'Restauration annuelle réservée au PC'}),
  backup:()=>({ok:false,error:'Utilisez Export opérations Android dans la fenêtre Synchronisation'}),
  importLegacy:()=>({ok:false,error:'Import SQLite réservé au PC principal'}),
  syncExportMaster:()=>({ok:false,error:'Fonction PC : utilisez Export opérations Android'}),
  syncPreviewMobile:()=>({ok:false,error:'Fonction PC : utilisez Import base PC'}),
  syncApplyMobile:()=>({ok:false,error:'Fonction PC réservée au logiciel Windows'})
 });
 window.rizerieMobileResult=function(msg){alert(msg);};
 function popup(){
   let p=document.getElementById('mobile-sync-modal');if(p){p.remove();return;}
   p=document.createElement('div');p.id='mobile-sync-modal';p.style.cssText='position:fixed;z-index:99999;inset:0;background:#061e3abb;display:grid;place-items:center;padding:14px';
   const panel=document.createElement('div');panel.style.cssText='background:white;color:#123258;max-width:460px;width:100%;padding:24px;border-radius:17px;box-shadow:0 15px 50px #01152955';
   panel.innerHTML='<h2 style="margin-top:0">Synchronisation Android</h2><p>Le PC reste la base principale. Transférez les fichiers .rpsync par USB ou partage Wi-Fi local.</p><label style="display:block;margin-bottom:8px">Code de synchronisation (10 caractères minimum)</label><input id="mobile-sync-pass" type="password" style="width:100%;padding:12px;margin-bottom:12px"><div id="mobile-sync-count" style="padding:9px;background:#edf5ff;margin-bottom:10px;border-radius:8px"></div><button id="mobile-export" style="width:100%;padding:13px;margin-bottom:8px;background:#0b6ed5;color:white;border:0;border-radius:8px">Exporter opérations vers PC</button><button id="mobile-import" style="width:100%;padding:13px;margin-bottom:8px;background:#118449;color:white;border:0;border-radius:8px">Importer base actualisée depuis PC</button><button id="mobile-close" style="width:100%;padding:10px;background:#eef2f7;border:0;border-radius:8px">Fermer</button>';
   p.append(panel);document.body.append(p);
   document.getElementById('mobile-sync-count').textContent=rpc('device').pending+' opération(s) en attente de synchronisation';
   document.getElementById('mobile-close').onclick=()=>p.remove();
   document.getElementById('mobile-export').onclick=()=>{const r=rpc('export',{pass:document.getElementById('mobile-sync-pass').value});if(!r.ok)alert(r.error);};
   document.getElementById('mobile-import').onclick=()=>{const r=rpc('import',{pass:document.getElementById('mobile-sync-pass').value});if(!r.ok)alert(r.error);};
 }
 document.addEventListener('DOMContentLoaded',()=>{
  if(!document.getElementById('page'))return;
  const observer=new MutationObserver(()=>{for(const h of document.querySelectorAll('.panel-title')){const t=h.textContent||'';if(t.includes('Synchronisation Android — USB / Wi-Fi local')||t.includes('Nouvelle année — Clôture annuelle'))h.closest('.panel').style.display='none';}});observer.observe(document.getElementById('page'),{childList:true,subtree:true});
  const b=document.createElement('button');b.textContent='⇄ Synchronisation Android';b.id='mobile-sync-toggle';b.type='button';
  b.style.cssText='position:fixed;bottom:15px;right:15px;z-index:99000;border:0;border-radius:22px;background:#0866c7;color:white;padding:14px 18px;box-shadow:0 8px 24px #092b5c77;font-weight:800';b.onclick=popup;document.body.append(b);
 });
})();
