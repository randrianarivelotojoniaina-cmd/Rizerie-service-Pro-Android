'use strict';
const assert=require('node:assert/strict');
const Sync=require('../desktop/app/sync_core');
const Alias=require('../desktop/app/sync_site_link');
const {emptyState,validate,validateChange}=require('../desktop/app/state');
const {Store}=require('../desktop/app/store');
const SyncDesktop=require('../desktop/app/sync_desktop');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
function makeSite(s,id,name,start='2026-11-01'){
 s.sites.push({id,name,tarif:100,gasReadingIndex:0,startDate:start});
 s.magasins.push({id:'m'+id,name:'Magasin Rizerie '+name,siteId:id});
 s.caisses.push({id:'c'+id,name:'Caisse Rizerie '+name,siteId:id,solde:0});
 s.stocks['m'+id]={};s.stockValues['m'+id]={};
 s.seasons.push({id:'ss'+id.slice(1),siteId:id,number:1,start,end:null,status:'active',inferred:false,createdAt:'2026-11-01T00:00:00Z'});
 s.nextSite=Math.max(s.nextSite,Number(id.slice(1))+1);
 s.nextSeason=Math.max(s.nextSeason,Number(id.slice(1))+1);
}
const sourceStart=emptyState(), android=structuredClone(sourceStart);
makeSite(android,'r1','Alpha','2026-11-15');
const changes=Sync.diff(sourceStart,android);
const event={id:'12345678-1234-4123-8123-123456789012',deviceId:'android_device_test',createdAt:'2026-11-15T11:00:00Z',changes};
const pc=emptyState();makeSite(pc,'r8','Alpha','2026-11-01');
assert.equal(Alias.remap(pc,event,new Map(),false).needsLink,true,'Identical names require manual confirmation');
const linked=Alias.remap(pc,event,new Map(),true);
assert.equal(linked.needsLink,false);
assert.equal(linked.candidates[0].sourceId,'r1');
assert.equal(linked.candidates[0].targetId,'r8');
assert.equal(linked.event.changes.created.sites,undefined);
assert.equal(linked.event.changes.created.magasins,undefined);
assert.equal(linked.event.changes.created.caisses,undefined);
assert.equal(linked.event.changes.created.seasons,undefined);
const next=Sync.apply(pc,linked.event);
validate(next);validateChange(pc,next);
assert.equal(next.sites.length,1);
assert.equal(next.magasins.length,2); // Central + existing linked magasin
assert.equal(next.caisses.length,2);
assert.equal(next.seasons.length,1);
assert.equal(next.sites[0].id,'r8');
const aliased=new Map(linked.aliases);
const later={id:'12345678-1234-4123-8123-123456789013',deviceId:event.deviceId,createdAt:'2026-11-15T12:00:00Z',changes:{created:{prestations:[{id:'p1',siteId:'r1',date:'2026-11-15',kg:250,tarif:100,recette:25000}]},updated:{},values:{},counters:{},extra:{}}};
const laterMap=Alias.remap(next,later,aliased,false);
assert.equal(laterMap.event.changes.created.prestations[0].siteId,'r8');
const imported=Sync.apply(next,laterMap.event);validate(imported);validateChange(next,imported);
assert.equal(imported.prestations.length,1);
assert.equal(imported.prestations[0].siteId,'r8');
const pcSameId=emptyState();makeSite(pcSameId,'r1','Alpha');
const sameLink=Alias.remap(pcSameId,event,new Map(),true);
assert.equal(sameLink.candidates[0].sameId,true);
const mergedSameId=Sync.apply(pcSameId,sameLink.event);
assert.equal(mergedSameId.sites.length,1,'Same r1 on both devices must not create duplicate');
validate(mergedSameId);
const different=emptyState();makeSite(different,'r1','BETA');
assert.throws(()=>Sync.apply(different,Alias.remap(different,event,new Map(),false).event),/Conflit identifiant/, 'Different site with ID collision must not merge');
const malicious=structuredClone(event);malicious.changes.created.movements=[{ref:'MVT-00001',date:'2026-11-15',type:'Stock initial'}];
assert.throws(()=>Alias.remap(pc,malicious,new Map(),true),/rapprochement comptable manuel/);

// Persistence, audit, and UUID replay without modifying user's data.
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rizerie-site-test-'));
let store;
try{
 store=new Store(dir);
 let s=store.getState();const seed=structuredClone(s.data);makeSite(seed,'r8','Alpha','2026-11-01');
 assert.equal(store.save({revision:s.revision,data:seed,import:true}).ok,true);
 const pkg={product:'Rizerie Service Pro',format:1,kind:'mobile-events',deviceId:event.deviceId,events:[event,later]};
 let review=SyncDesktop.preview(store,pkg);
 assert.equal(review.events[0].status,'site-link');
 const result=SyncDesktop.importEvents(store,pkg,{[event.id]:'link-site'});
 assert.equal(result.imported,2,JSON.stringify(result.conflicts));
 assert.equal(result.siteAliases,4);
 assert.equal(store.getState().data.sites.length,1);
 assert.equal(store.getState().data.prestations[0].siteId,'r8');
 const re=SyncDesktop.importEvents(store,pkg,{});
 assert.equal(re.imported,0);
 assert.equal(re.skipped.length,2);
 assert.equal(store.db.prepare('SELECT count(*) as c FROM sync_entity_alias').get().c,4);
 assert.equal(store.db.prepare("SELECT count(*) as c FROM audit_log WHERE operation='SYNC_ANDROID'").get().c,1);
 console.log('OK: explicit site-link; aliases persisted; dependent references rewritten; UUID replay ignored; backup/audit');
}finally{try{store?.db.close()}catch(_){}fs.rmSync(dir,{recursive:true,force:true});}
