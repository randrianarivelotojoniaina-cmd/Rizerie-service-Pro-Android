'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const p = require('../desktop/app/wifi_qr_pairing');

function get(host, port, token) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host, port, path: '/pair/status', headers: { 'X-Rizerie-Pair-Token': token, Connection: 'close' } }, res => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
  });
}

(async () => {
  assert.equal(p.privateIPv4('192.168.0.20'), true);
  assert.equal(p.privateIPv4('10.5.5.9'), true);
  assert.equal(p.privateIPv4('172.20.1.1'), true);
  assert.equal(p.privateIPv4('8.8.8.8'), false);
  assert.equal(p.privateIPv4('127.0.0.1'), false);
  assert.equal(p.privateIPv4('192.168.999.1'), false);

  const selected = p.chooseLocalInterface([
    { label: 'Local Area Connection* 10', address: '192.168.137.1', virtual: true, wifi: false },
    { label: 'Wi-Fi', address: '192.168.158.238', virtual: false, wifi: true },
    { label: 'Ethernet', address: '10.0.0.8', virtual: false, wifi: false }
  ]);
  assert.equal(selected.address, '192.168.158.238');
  assert.equal(p.chooseLocalInterface([
    { label: 'Ethernet', address: '10.0.0.8', virtual: false, wifi: false },
    { label: 'Ethernet 2', address: '192.168.1.8', virtual: false, wifi: false }
  ], '192.168.1.8').address, '192.168.1.8');
  assert.throws(() => p.chooseLocalInterface([
    { label: 'Wi-Fi', address: '192.168.1.8', virtual: false, wifi: true },
    { label: 'Wi-Fi 2', address: '192.168.2.8', virtual: false, wifi: true }
  ]), /Plusieurs interfaces Wi-Fi/);

  const r = await p.start('127.0.0.1');
  try {
    assert(r.payload.startsWith('RIZERIEPAIR:'));
    assert(r.port >= 1024 && r.port <= 65535);
    assert.equal(r.host, '127.0.0.1');
    assert.equal(r.interfaceName, 'Loopback de test');
    assert.equal(r.bindAddress, '0.0.0.0');
    assert.equal(r.verified, true);
    const decoded = JSON.parse(r.payload.slice('RIZERIEPAIR:'.length));
    assert.equal(decoded.type, 'RIZERIE_PAIR');
    assert.equal(decoded.version, 1);
    assert.equal(decoded.port, r.port);
    assert(decoded.expiresAt > Date.now());
    assert.equal((await get('127.0.0.1', r.port, 'wrong')).status, 401);
    const good = await get('127.0.0.1', r.port, decoded.token);
    assert.equal(good.status, 200);
    assert.equal(JSON.parse(good.body).transferStarted, false);
    assert.equal(JSON.parse(good.body).type, 'pairing-check');
  } finally {
    p.stop();
  }
  console.log('QR pairing tests OK — interface Wi-Fi, port réel, token, contrôle local; aucun transfert de données');
})().catch(e => { p.stop(); console.error(e); process.exitCode = 1; });
