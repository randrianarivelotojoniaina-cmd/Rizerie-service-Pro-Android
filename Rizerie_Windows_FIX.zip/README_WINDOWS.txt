RIZERIE SERVICE PRO V2.7 — CORRECTIF RÉSEAU QR (SOURCE)

PÉRIMÈTRE
- Corrige la sélection de l'interface réseau : priorité à l'interface Wi-Fi active, exclusion des adaptateurs virtuels connus et recours à la route IPv4 par défaut sous Windows si plusieurs interfaces restent ambiguës.
- Le serveur d'appairage écoute sur 0.0.0.0 avec un port TCP réellement attribué par Windows (port 0), puis annonce uniquement le port retourné par server.address().
- Vérification HTTP locale de l'adresse/du port avant d'afficher le QR.
- Affichage de l'interface sélectionnée, de l'adresse, du port et du compte à rebours d'expiration.
- QR temporaire de 5 minutes, jeton aléatoire, comparaison du jeton en temps constant.
- Le QR sert uniquement à vérifier la présence du PC. Il n'accède pas à SQLite et ne transfère aucune donnée.

TESTS
- Sélection d'une interface Wi-Fi plutôt qu'une interface virtuelle.
- Sélection par route IPv4 par défaut en cas d'interfaces non Wi-Fi multiples.
- Refus d'une sélection ambiguë entre plusieurs interfaces Wi-Fi.
- Vérification du port réellement attribué, de l'adresse de liaison, du jeton et du point HTTP local.
- Tests métier de synchronisation et de liaison des rizeries conservés.

LIMITES
- Les tests automatiques locaux ne remplacent pas un test réel PC Windows ↔ téléphone Android en partage de connexion.
- Le pare-feu Windows doit autoriser l'application sur le profil réseau utilisé.
- Le QR est un appairage uniquement. Le transfert Wi-Fi direct des données métier n'est pas inclus dans ce correctif.
- Ne pas remplacer ni supprimer la base SQLite de production. La compilation Windows doit conserver l'isolation de la base de test V2.7.
