'use strict';
const Seasons = require('./seasons');
const { validate } = require('./state');

function day(x){const s=String(x??'').slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(s)?s:null;}
function monthDays(year,month){return new Date(year,month,0).getDate();}
function statusAt(employee,date){
  if(date<(employee.hired||'0000-01-01'))return 'Avant embauche';
  let status='Actif';
  for(const e of (employee.statusEvents||[]).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date)))){
    if(e.date<=date)status=e.status;else break;
  }
  return status;
}
function purchaseStatus(o){
  if(o.status==='Annulé')return 'Annulé';
  const total=(o.lines||[]).reduce((a,l)=>a+Number(l.qty||0),0);
  const received=(o.lines||[]).reduce((a,l)=>a+Number(l.received||0),0);
  return received>=total-1e-7?'Reçu':received>0?'Partiellement reçu':'À recevoir';
}
function payrollReview(state,year){
  const missing=[],unpaid=[];
  const attendance=new Map((state.attendance||[]).map(a=>[`${a.employeeId}|${a.date}`,a]));
  const paid=new Map();
  for(const p of state.payments||[]){
    const period=/^\d{4}-\d{2}$/.test(String(p.period||''))?p.period:day(p.date)?.slice(0,7);
    if(!period)continue;
    const key=`${p.employeeId}|${period}`;paid.set(key,(paid.get(key)||0)+Number(p.amount||0));
  }
  for(const employee of state.employees||[]){
    if((employee.statusEvents||[]).some(x=>x.needsReview)){
      missing.push({employee:employee.name,period:'Statut',days:0,reason:'Date de désactivation à vérifier'});
      continue;
    }
    const rate=employee.contract==='mensuel'?Number(employee.monthlyPay||0):Number(employee.dailyPay||0);
    if(rate<=0)continue;
    for(let month=1;month<=12;month++){
      const period=`${year}-${String(month).padStart(2,'0')}`;
      const totalDays=monthDays(year,month),activeDays=[];
      for(let d=1;d<=totalDays;d++){
        const date=`${period}-${String(d).padStart(2,'0')}`;
        if(date<(employee.hired||'0000-01-01'))continue;
        if(statusAt(employee,date)==='Actif')activeDays.push(date);
      }
      if(!activeDays.length)continue;
      const notEntered=activeDays.filter(date=>!attendance.has(`${employee.id}|${date}`));
      if(notEntered.length){
        missing.push({employee:employee.name,period,days:notEntered.length,reason:'Calendrier de présence non entièrement validé'});
        continue;
      }
      const present=activeDays.filter(date=>attendance.get(`${employee.id}|${date}`)?.status==='Présent').length;
      const accrued=employee.contract==='mensuel'?rate*present/totalDays:rate*present;
      const amountPaid=paid.get(`${employee.id}|${period}`)||0;
      if(accrued-amountPaid>0.01)unpaid.push({employee:employee.name,period,accrued:Math.round(accrued*100)/100,paid:Math.round(amountPaid*100)/100,due:Math.round((accrued-amountPaid)*100)/100});
    }
  }
  return {missing,unpaid};
}
function operationCounts(s){
  return {
    prestations:(s.prestations||[]).length,
    mouvements:(s.movements||[]).length,
    ventes:(s.sales||[]).length,
    consommations:(s.consumptions||[]).length,
    relevesGasoil:(s.readings||[]).length,
    presences:(s.attendance||[]).length,
    paiements:(s.payments||[]).length,
    bonsCommande:(s.purchaseOrders||[]).length,
    historiqueTarifs:(s.tarifHistory||[]).length,
    stocksInitiaux:(s.openingStocks||[]).length
  };
}
function preflight(state,newYear,asOf=new Date()){
  const currentYear=Number.isSafeInteger(state.exerciseYear)?state.exerciseYear:asOf.getFullYear();
  const issues=[],warnings=[];
  if(!Number.isInteger(newYear)||newYear!==currentYear+1)issues.push(`L'exercice suivant doit être ${currentYear+1}.`);
  const yearEnd=`${currentYear}-12-31`,yearStart=`${currentYear}-01-01`;
  const today=`${asOf.getFullYear()}-${String(asOf.getMonth()+1).padStart(2,'0')}-${String(asOf.getDate()).padStart(2,'0')}`;
  if(today<=yearEnd){
    issues.push(`Clôture annuelle possible uniquement après le ${yearEnd}.`);
    return {ok:false,currentYear,newYear,yearStart,yearEnd,issues,warnings,openPurchaseOrders:[],payrollMissing:[],payrollUnpaid:[],seasonClosuresRequired:0,counts:operationCounts(state),master:{rizeries:(state.sites||[]).length,articles:(state.articles||[]).length,categories:new Set((state.articles||[]).map(a=>a.category)).size,personnel:(state.employees||[]).length,magasins:(state.magasins||[]).length,caisses:(state.caisses||[]).length}};
  }
  const datedKinds=['prestations','movements','readings','sales','consumptions','attendance','payments','purchaseOrders','openingStocks','tarifHistory'];
  const after=[];
  for(const kind of datedKinds)for(const item of state[kind]||[]){const d=day(item.date);if(d&&d>yearEnd)after.push({kind,date:d,ref:item.ref||item.id||''});}
  for(const employee of state.employees||[])for(const event of employee.statusEvents||[]){const d=day(event.date);if(d&&d>yearEnd)after.push({kind:'statut personnel',date:d,ref:employee.ref||employee.name||employee.id||''});}
  if(after.length)issues.push(`${after.length} opération(s) ou changement(s) de statut sont datés après le ${yearEnd}. Corrigez-les avant la clôture.`);
  const openOrders=(state.purchaseOrders||[]).filter(o=>!['Reçu','Annulé'].includes(purchaseStatus(o)));
  if(openOrders.length)issues.push(`${openOrders.length} bon(s) de commande encore ouvert(s) ou partiellement reçu(s) : réceptionnez-les ou annulez-les avant clôture.`);
  for(const mag of state.magasins||[])for(const article of state.articles||[]){
    const qty=Number(state.stocks?.[mag.id]?.[article.id]||0),value=state.stockValues?.[mag.id]?.[article.id];
    if(qty>0&&(value===null||value===undefined))warnings.push(`Coût de stock non valorisé : ${mag.name} / ${article.name} (${qty} ${article.unit}). La quantité sera reportée, mais pas de valeur de coût inventée.`);
  }
  const payroll=payrollReview(state,currentYear);
  if(payroll.missing.length)issues.push(`${payroll.missing.length} période(s) de présence/paie nécessitent une validation avant clôture.`);
  if(payroll.unpaid.length)issues.push(`${payroll.unpaid.length} salaire(s) acquis restent impayés. Réglez-les avant clôture.`);
  const seasonCheck=structuredClone(state);
  for(const site of seasonCheck.sites||[]){
    const active=Seasons.active(seasonCheck,site.id);
    if(active){
      try{Seasons.close(seasonCheck,site.id,yearEnd);}
      catch(e){issues.push(`${site.name} — ${e.message}`);}
    } else {
      const list=Seasons.bySite(seasonCheck,site.id),last=list[list.length-1];
      if(!last)issues.push(`${site.name} : aucune saison enregistrée.`);
      else if(last.start>yearEnd||last.end&&last.end>yearEnd)issues.push(`${site.name} : période de saison incompatible avec la clôture ${currentYear}.`);
    }
  }
  const openSeasons=(seasonCheck.seasons||[]).filter(s=>s.status==='active').length;
  return {
    ok:issues.length===0,
    currentYear,newYear,yearStart,yearEnd,
    issues,warnings,
    openPurchaseOrders:openOrders.map(o=>({ref:o.ref||o.id,supplier:o.supplier,status:purchaseStatus(o)})),
    payrollMissing:payroll.missing,
    payrollUnpaid:payroll.unpaid,
    seasonClosuresRequired:openSeasons,
    counts:operationCounts(state),
    master:{rizeries:(state.sites||[]).length,articles:(state.articles||[]).length,categories:new Set((state.articles||[]).map(a=>a.category)).size,personnel:(state.employees||[]).length,magasins:(state.magasins||[]).length,caisses:(state.caisses||[]).length}
  };
}
function makeNewYearState(closedState,newYear,now=new Date()){
  const next=structuredClone(closedState),start=`${newYear}-01-01`;
  next.exerciseYear=newYear;next.yearOpenedAt=now.toISOString();next.previousExerciseYear=newYear-1;
  next.prestations=[];next.movements=[];next.tarifHistory=[];next.readings=[];next.sales=[];next.consumptions=[];
  next.attendance=[];next.payments=[];next.purchaseOrders=[];next.openingStocks=[];
  next.nextOperation=1;next.nextPurchaseOrder=1;next.nextAttendance=1;next.nextOpeningStock=1;
  for(const site of next.sites||[]){site.gasReadingIndex=0;site.startDate=start;}
  for(const employee of next.employees||[]){
    let status=employee.status||'Actif';
    for(const event of (employee.statusEvents||[]).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))))if(event.date<=`${newYear-1}-12-31`)status=event.status;
    employee.status=status;
    employee.statusEvents=[{date:start,status,note:`Statut reporté à l'ouverture de l'exercice ${newYear}`,createdAt:now.toISOString()}];
  }
  for(const cash of next.caisses||[]){cash.openingSolde=Number(cash.solde||0);cash.openingYear=newYear;cash.openingDate=start;}
  let n=1;
  for(const mag of next.magasins||[]){
    next.stocks[mag.id]??={};next.stockValues[mag.id]??={};
    for(const article of next.articles||[]){
      const qty=Number(next.stocks[mag.id][article.id]||0);
      const raw=next.stockValues[mag.id][article.id];
      const value=raw===null||raw===undefined?null:Number.isFinite(raw)?Number(raw):0;
      if(value===null)next.stockValues[mag.id][article.id]=null;
      if(qty<=0)continue;
      const price=value===null?null:Math.round((value/qty)*100)/100;
      next.openingStocks.push({id:`si${n}`,ref:`SI-${String(n).padStart(3,'0')}`,date:start,magId:mag.id,articleId:article.id,qty,price,value,annualCarryForward:true,sourceYear:newYear-1,targetYear:newYear});
      n++;
    }
  }
  next.nextOpeningStock=n;
  next.seasons=[];next.nextSeason=1;
  for(const site of next.sites||[])Seasons.createFirst(next,site.id,start);
  validate(next);
  return next;
}
module.exports={day,statusAt,purchaseStatus,payrollReview,operationCounts,preflight,makeNewYearState};
