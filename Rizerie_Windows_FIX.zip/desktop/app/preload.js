'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const allowed={
 isConfigured:()=>ipcRenderer.sendSync('auth:configured'),
 createAdmin:(password,confirm)=>ipcRenderer.sendSync('auth:setup',{password,confirm}),
 login:(password)=>ipcRenderer.sendSync('auth:login',password),
 logout:()=>ipcRenderer.sendSync('auth:logout'),
 state:()=>ipcRenderer.sendSync('db:state'),
 saveState:(payload)=>ipcRenderer.sendSync('db:save',payload),
 backup:()=>ipcRenderer.sendSync('db:backup'),
 importLegacy:()=>ipcRenderer.sendSync('db:importlegacy'),
 audit:()=>ipcRenderer.sendSync('db:audit'),
 syncPairingStart:()=>ipcRenderer.invoke('sync:pair-start'),
 syncExportMaster:pass=>ipcRenderer.sendSync('sync:export-master',pass),
 syncPreviewMobile:pass=>ipcRenderer.sendSync('sync:preview-mobile',pass),
 syncApplyMobile:decisions=>ipcRenderer.sendSync('sync:apply-mobile',decisions),
 annualPreview:(newYear)=>ipcRenderer.sendSync('db:annual-preview',newYear),
 annualClose:(newYear)=>ipcRenderer.sendSync('db:annual-close',newYear),
 annualArchives:()=>ipcRenderer.sendSync('db:annual-archives'),
 verifyAnnualArchive:()=>ipcRenderer.sendSync('db:annual-verify'),
 restoreAnnualArchive:()=>ipcRenderer.sendSync('db:annual-restore')
};
contextBridge.exposeInMainWorld('rizerieDesktop',Object.freeze(allowed));
