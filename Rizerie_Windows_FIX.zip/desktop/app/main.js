'use strict';
const path=require('node:path');
const {fileURLToPath}=require('node:url');
const {app,BrowserWindow,ipcMain,dialog,Menu}=require('electron');
const {Store}=require('./store');
const SyncDesktop=require('./sync_desktop');
const fs=require('node:fs');
const QrPairing=require('./wifi_qr_pairing');
const APP_DIR=path.resolve(__dirname);
const dataRoot=path.join(process.env.LOCALAPPDATA||app.getPath('userData'),'RizerieServicePro');
app.setName('Rizerie Service Pro');
app.setPath('userData',dataRoot);
let win,store,loggedIn=false;let pendingMobilePackage=null;
function locationIsOwned(event){try{return !!win && event.sender.id===win.webContents.id && !event.sender.isDestroyed()}catch(_){return false}}
function secureHandler(channel,fn,requireLogin=true){ipcMain.on(channel,(e,arg)=>{
 try{
  if(!locationIsOwned(e))throw Error('Fenêtre non autorisée');
  if(requireLogin&&!loggedIn)throw Error('Session non autorisée');
  e.returnValue=fn(arg);
 }catch(ex){e.returnValue={ok:false,error:String(ex.message)}}
});}
function connect(){store=new Store(path.join(dataRoot,'data'))}
function open(){
 win=new BrowserWindow({width:1440,height:900,minWidth:920,minHeight:640,show:false,title:'Rizerie Service Pro',
  backgroundColor:'#eff5fd',autoHideMenuBar:true,icon:path.join(APP_DIR,'icon.ico'),
  webPreferences:{preload:path.join(APP_DIR,'preload.js'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,spellcheck:false,webviewTag:false,devTools:false}});
 Menu.setApplicationMenu(null);
 const permitted=new Set(['index.html','login.html']);
 win.webContents.on('will-navigate',(e,url)=>{
  try{const u=new URL(url);if(u.protocol!=='file:'||!permitted.has(path.relative(APP_DIR,fileURLToPath(u)))){e.preventDefault()}}
  catch(_){e.preventDefault()}
 });
 win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 win.webContents.on('will-attach-webview',e=>e.preventDefault());
 win.once('ready-to-show',()=>win.show());
 win.loadFile(path.join(APP_DIR,'login.html'));
 win.on('closed',()=>{QrPairing.stop();loggedIn=false;win=null});
}
app.whenReady().then(()=>{
 connect();
 secureHandler('auth:configured',()=>({ok:true,configured:store.hasAdmin()}),false);
 secureHandler('auth:setup',({password,confirm}={})=>{const r=store.setup(password,confirm);if(r.ok)loggedIn=true;return r},false);
 secureHandler('auth:login',pass=>{const r=store.checkPassword(pass);if(r.ok)loggedIn=true;return r},false);
 secureHandler('auth:logout',()=>{QrPairing.stop();loggedIn=false;win?.loadFile(path.join(APP_DIR,'login.html'));return {ok:true}});
 secureHandler('db:state',()=>store.getState());
 secureHandler('db:save',body=>store.save(body));
 secureHandler('db:audit',()=>({ok:true,audits:store.audit()}));
 secureHandler('db:backup',()=>{
  const target=dialog.showSaveDialogSync(win,{title:'Sauvegarder la base SQLite',defaultPath:'Rizerie_Sauvegarde_'+new Date().toISOString().slice(0,10)+'.sqlite3',filters:[{name:'SQLite',extensions:['sqlite3']} ]});
  if(!target)return {ok:false,cancelled:true};
  return {ok:true,file:store.backup('export',target)};
 });
 secureHandler('db:importlegacy',()=>{
  const picked=dialog.showOpenDialogSync(win,{title:'Importer ancienne base SQLite V1.x',properties:['openFile'],filters:[{name:'SQLite',extensions:['sqlite3','db']} ]});
  if(!picked?.length)return {ok:false,cancelled:true};
  const yes=dialog.showMessageBoxSync(win,{type:'warning',buttons:['Annuler','Importer'],defaultId:0,cancelId:0,title:'Confirmer la migration',message:'La base sélectionnée est-elle bien votre ancienne base Rizerie V1.x ?',detail:'Le programme enregistrera une sauvegarde avant l’opération et refusera la migration si la base actuelle contient déjà des opérations.'});
  if(yes!==1)return {ok:false,cancelled:true};
  return store.importOldBase(picked[0]);
 });
 ipcMain.handle('sync:pair-start',async e=>{
  try{if(!locationIsOwned(e)||!loggedIn)throw Error('Session PC non autorisée');
   const info=await QrPairing.start();return {ok:true,...info,svg:QrPairing.qrSvg(info.payload)};
  }catch(ex){QrPairing.stop();return {ok:false,error:String(ex.message)}}
 });
 secureHandler('sync:export-master',passphrase=>{
  const target=dialog.showSaveDialogSync(win,{title:'Exporter référentiels et données vers Android',defaultPath:'Rizerie_PC_vers_Android.rpsync',filters:[{name:'Synchronisation Rizerie',extensions:['rpsync']}]});
  if(!target)return {ok:false,cancelled:true};
  fs.writeFileSync(target,SyncDesktop.exportMaster(store,passphrase),{flag:'wx',mode:0o600});return {ok:true,file:target};
 });
 secureHandler('sync:preview-mobile',passphrase=>{
  const picked=dialog.showOpenDialogSync(win,{title:'Importer opérations Android',properties:['openFile'],filters:[{name:'Synchronisation Rizerie',extensions:['rpsync']}]});
  if(!picked?.length)return {ok:false,cancelled:true};
  pendingMobilePackage=SyncDesktop.readPackage(picked[0],passphrase);
  return SyncDesktop.preview(store,pendingMobilePackage);
 });
 secureHandler('sync:apply-mobile',decisions=>{
  if(!pendingMobilePackage)return {ok:false,error:'Aucun paquet à importer'};
  const result=SyncDesktop.importEvents(store,pendingMobilePackage,decisions||{});
  pendingMobilePackage=null;return result;
 });
 secureHandler('db:annual-preview' ,newYear=>store.previewAnnualClose(newYear));
 secureHandler('db:annual-archives',()=>({ok:true,archives:store.listAnnualClosures()}));
 secureHandler('db:annual-close',newYear=>{
  const previewResult=store.previewAnnualClose(newYear);
  if(!previewResult.ok)return previewResult;
  const preview=previewResult.preview;
  if(!preview.ok)return {ok:false,error:preview.issues.join('\n'),preview};
  const defaultPath=path.join(app.getPath('documents'),`Rizerie_Archive_${preview.currentYear}.sqlite3`);
  const picked=dialog.showSaveDialogSync(win,{title:`Sauvegarde complète avant clôture ${preview.currentYear}`,defaultPath,filters:[{name:'Archive SQLite',extensions:['sqlite3']}]});
  if(!picked)return {ok:false,cancelled:true};
  const detail=`Exercice ${preview.currentYear} → ${preview.newYear}.\n\nArchive complète : ${picked}\n\nOpérations archivées : ${Object.values(preview.counts).reduce((a,b)=>a+b,0)}\nStocks reportés : calculés article par magasin.\nCaisses reportées : ${preview.master.caisses}.\nRizeries conservées : ${preview.master.rizeries}.\nArticles / catégories conservés : ${preview.master.articles} / ${preview.master.categories}.\nPersonnel conservé : ${preview.master.personnel}.\n\nLes historiques seront retirés de l’exercice actif, mais conservés dans l’archive vérifiée. Les stocks, gasoil et soldes ne seront pas remis à zéro.`;
  const yes=dialog.showMessageBoxSync(win,{type:'warning',buttons:['Annuler','Confirmer clôture annuelle'],defaultId:0,cancelId:0,title:'DOUBLE CONTRÔLE — Nouvelle année',message:'Confirmez-vous définitivement la clôture et l’ouverture du nouvel exercice ?',detail});
  if(yes!==1)return {ok:false,cancelled:true};
  return store.closeYear(Number(newYear),picked);
 });
 secureHandler('db:annual-verify',()=>{
  const picked=dialog.showOpenDialogSync(win,{title:'Vérifier une archive annuelle SQLite',properties:['openFile'],filters:[{name:'Archive SQLite',extensions:['sqlite3','db']}]});
  if(!picked?.length)return {ok:false,cancelled:true};
  return store.verifyAnnualArchive(picked[0],true);
 });
 secureHandler('db:annual-restore',()=>{
  const picked=dialog.showOpenDialogSync(win,{title:'Restaurer une archive annuelle SQLite',properties:['openFile'],filters:[{name:'Archive SQLite',extensions:['sqlite3','db']}]});
  if(!picked?.length)return {ok:false,cancelled:true};
  const verified=store.verifyAnnualArchive(picked[0]);
  if(!verified.ok)return verified;
  const yes=dialog.showMessageBoxSync(win,{type:'warning',buttons:['Annuler','Restaurer cette archive'],defaultId:0,cancelId:0,title:'Restaurer exercice '+verified.exerciseYear,message:'La base opérationnelle actuelle sera remplacée par l’état archivé.',detail:'Une sauvegarde automatique de la base actuelle sera créée avant restauration. Le compte administrateur courant sera conservé. Archive : '+picked[0]+'\nSHA-256 : '+verified.sha256});
  if(yes!==1)return {ok:false,cancelled:true};
  return store.restoreAnnualArchive(picked[0]);
 });
 open();
}).catch(ex=>{dialog.showErrorBox('Rizerie Service Pro — Démarrage impossible',String(ex.stack||ex));app.quit()});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',()=>{QrPairing.stop();try{store?.close()}catch(_){}});
