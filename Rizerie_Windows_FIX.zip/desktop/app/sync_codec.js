'use strict';
const crypto=require('node:crypto');
const ITERATIONS=150000;
const AAD=Buffer.from('Rizerie-Service-Pro-rpsync-v1','utf8');
function encode(data,pass){
 if(typeof pass!=='string'||pass.length<10)throw Error('Code de synchronisation : au moins 10 caractères.');
 const salt=crypto.randomBytes(16),iv=crypto.randomBytes(12),key=crypto.pbkdf2Sync(pass,salt,ITERATIONS,32,'sha256');
 const cipher=crypto.createCipheriv('aes-256-gcm',key,iv);cipher.setAAD(AAD);
 const plain=Buffer.from(JSON.stringify(data),'utf8'),ciphertext=Buffer.concat([cipher.update(plain),cipher.final(),cipher.getAuthTag()]);
 return JSON.stringify({format:'rpsync-encrypted',v:1,iterations:ITERATIONS,salt:salt.toString('base64'),iv:iv.toString('base64'),ciphertext:ciphertext.toString('base64')});
}
function decode(envelope,pass){
 const body=typeof envelope==='string'?JSON.parse(envelope):envelope;
 if(body?.format!=='rpsync-encrypted'||body.v!==1||body.iterations!==ITERATIONS)throw Error('Format rpsync non reconnu.');
 const salt=Buffer.from(body.salt,'base64'),iv=Buffer.from(body.iv,'base64'),bytes=Buffer.from(body.ciphertext,'base64');
 if(salt.length!==16||iv.length!==12||bytes.length<17||bytes.length>24*1024*1024)throw Error('Paquet de synchronisation invalide ou trop volumineux.');
 if(typeof pass!=='string'||!pass)throw Error('Code de synchronisation requis');
 const key=crypto.pbkdf2Sync(pass,salt,ITERATIONS,32,'sha256');
 const decipher=crypto.createDecipheriv('aes-256-gcm',key,iv);decipher.setAAD(AAD);decipher.setAuthTag(bytes.subarray(-16));
 const raw=Buffer.concat([decipher.update(bytes.subarray(0,-16)),decipher.final()]);
 return JSON.parse(raw.toString('utf8'));
}
module.exports={encode,decode,ITERATIONS};
