'use strict';
// Intégrité métier, compatible avec les règles du serveur SQLite V1.x.
const seasons=require('./seasons');
const MAX_JSON = 8 * 1024 * 1024 - 200;
function ensure(ok, msg){if(!ok)throw new Error(msg)}
function arr(s,k){const v=s[k];ensure(Array.isArray(v)&&v.length<=100000&&v.every(x=>x&&typeof x==='object'&&!Array.isArray(x)),'Liste invalide : '+k);return v}
function validNum(x, nonnegative=true){return typeof x==='number'&&Number.isFinite(x)&&(!nonnegative||x>=-0.0000001)&&Math.abs(x)<1e15}
function uniqueRows(list,k){const ids=list.map(x=>String(x.id??''));ensure(ids.every(Boolean)&&new Set(ids).size===ids.length,'Identifiants en double : '+k)}
function emptyState(){return {
 exerciseYear:new Date().getFullYear(),yearOpenedAt:new Date().toISOString(),nextArticle:1,nextSite:1,nextOperation:1,nextPurchaseOrder:1,nextOpeningStock:1,nextEmployee:1,nextAttendance:1,
 articles:[],sites:[],magasins:[{id:'m0',name:'Magasin Central',siteId:null}],caisses:[{id:'c0',name:'Caisse Principale',siteId:null,solde:0}],
 stocks:{m0:{}},stockValues:{m0:{}},prestations:[],movements:[],tarifHistory:[],readings:[],sales:[],consumptions:[],
 employees:[],attendance:[],payments:[],purchaseOrders:[],openingStocks:[],seasons:[],nextSeason:1};}
function validate(s){
 ensure(s&&typeof s==='object'&&!Array.isArray(s),'État invalide');
 ensure(s.exerciseYear===undefined||Number.isSafeInteger(s.exerciseYear)&&s.exerciseYear>=2000&&s.exerciseYear<=9999,'Exercice comptable invalide');
 const arts=arr(s,'articles'),sites=arr(s,'sites'),mags=arr(s,'magasins'),caisses=arr(s,'caisses');
 for(const k of ['movements','prestations','sales','consumptions','readings','employees','attendance','payments','purchaseOrders','openingStocks','tarifHistory'])arr(s,k);
 seasons.validateSeasons(s);
 for(const k of ['articles','sites','magasins','caisses','employees'])uniqueRows(s[k],k);
 for(const k of ['stocks','stockValues'])ensure(s[k]&&typeof s[k]==='object'&&!Array.isArray(s[k]),'Structure manquante: '+k);
 const aIds=new Set(arts.map(x=>x.id)), siteIds=new Set(sites.map(x=>x.id)), mIds=new Set(mags.map(x=>x.id)), cIds=new Set(caisses.map(x=>x.id));
 ensure([...arts,...sites,...mags,...caisses].every(x=>String(x.name??'').trim()),'Nom vide');
 ensure(new Set(sites.map(x=>x.name.trim().toLocaleLowerCase())).size===sites.length,'Rizeries en double');
 for(const x of sites){ensure(validNum(x.tarif),'Tarif Rizerie invalide');ensure(mags.filter(y=>y.siteId===x.id).length===1,'Une rizerie doit avoir un magasin unique');ensure(caisses.filter(y=>y.siteId===x.id).length===1,'Une rizerie doit avoir une caisse unique')}
 for(const m of mags)ensure(m.siteId==null||siteIds.has(m.siteId),'Magasin lié à rizerie absente');
 for(const c of caisses){ensure(c.siteId==null||siteIds.has(c.siteId),'Caisse liée à rizerie absente');ensure(validNum(c.solde),'Solde caisse invalide');if(c.openingSolde!==undefined)ensure(validNum(c.openingSolde),'Solde initial caisse invalide');if(c.openingYear!==undefined)ensure(Number.isSafeInteger(c.openingYear),'Année du solde initial invalide')}
 for(const a of arts)ensure(validNum(a.price)&&(a.buyPrice==null||validNum(a.buyPrice)),'Prix article invalide');
 for(const [mag,stock] of Object.entries(s.stocks)){ensure(mIds.has(mag)&&stock&&typeof stock==='object'&&!Array.isArray(stock),'Magasin stock invalide');for(const [article,qty] of Object.entries(stock))ensure(aIds.has(article)&&validNum(qty),'Stock négatif/inconnu : '+article)}
 for(const [mag,stock] of Object.entries(s.stockValues)){ensure(mIds.has(mag)&&stock&&typeof stock==='object'&&!Array.isArray(stock),'Valeur magasin invalide');for(const [a,v] of Object.entries(stock))ensure(aIds.has(a)&&(v==null||validNum(v)),'Valeur stock incorrecte')}
 for(const p of s.prestations){ensure(siteIds.has(p.siteId),'Prestation sans rizerie');ensure(validNum(p.kg)&&p.kg>0&&validNum(p.tarif)&&validNum(p.recette),'Prestation invalide');ensure(Math.abs(p.kg*p.tarif-p.recette)<=0.03,'Recette prestation incohérente')}
 for(const m of s.movements){ensure(typeof m.ref==='string'&&typeof m.type==='string','Mouvement invalide');for(const [k,allowed] of [['magSourceId',mIds],['magDestId',mIds],['cashSourceId',cIds],['cashDestId',cIds],['articleId',aIds]])if(m[k]!=null)ensure(allowed.has(m[k]),'Référence mouvement invalide : '+k);for(const k of ['amount','quantity'])if(m[k]!=null)ensure(validNum(m[k]),'Mouvement invalide: '+k)}
 ensure(new Set(s.movements.map(x=>x.ref)).size===s.movements.length,'Référence mouvement en double');
 for(const v of s.sales){ensure(mIds.has(v.magId)&&aIds.has(v.articleId)&&cIds.has(v.cashId),'Vente avec références inconnues');ensure(['qty','total','cost','price'].every(k=>validNum(v[k])),'Vente invalide');ensure(Math.abs(v.qty*v.price-v.total)<=0.03,'Total vente incohérent')}
 const eIds=new Set(s.employees.map(x=>x.id));
 for(const x of s.payments)ensure(eIds.has(x.employeeId)&&cIds.has(x.cashId)&&validNum(x.amount),'Paiement incorrect');
 for(const o of s.purchaseOrders){ensure(mIds.has(o.magasinId),'Bon commande magasin inconnu');for(const l of o.lines??[]){ensure(aIds.has(l.articleId)&&['qty','price','received'].every(k=>validNum(l[k])),'Ligne bon invalide');ensure(l.received<=l.qty+1e-6,'Réception commande excède commande')}}
 for(const r of s.readings)ensure(siteIds.has(r.siteId)&&['consumed','paddy'].every(k=>validNum(r[k])),'Relevé diesel incorrect');
 for(const x of s.openingStocks)ensure(mIds.has(x.magId)&&aIds.has(x.articleId)&&validNum(x.qty)&&(x.price==null||validNum(x.price))&&(x.value==null||validNum(x.value)),'Report / stock initial invalide');
 ensure(Buffer.byteLength(JSON.stringify(s),'utf8')<=MAX_JSON,'Données trop volumineuses');
}
function validateChange(old, newer){
 ensure((old.exerciseYear??null)===(newer.exerciseYear??null),'Le changement d’exercice est réservé à la clôture annuelle.');
 seasons.validateSeasonChanges(old,newer);
 for(const c of old.caisses){const n=newer.caisses.find(x=>x.id===c.id);if(n)ensure((c.openingSolde??null)===(n.openingSolde??null)&&(c.openingYear??null)===(n.openingYear??null)&&(c.openingDate??null)===(n.openingDate??null),'Solde initial caisse modifié : '+c.name)}
 for(const k of ['prestations','sales','consumptions','readings','payments','openingStocks']){
  const a=old[k]??[],b=newer[k]??[];
  ensure(b.length>=a.length&&JSON.stringify(b.slice(0,a.length))===JSON.stringify(a),'Historique immuable modifié : '+k);
 }
 const a=old.movements,b=newer.movements,n=b.length-a.length;
 ensure(n>=0&&(!a.length||JSON.stringify(b.slice(n))===JSON.stringify(a)),'Historique mouvements modifié ou supprimé');
 const newEvents=b.slice(0,n);
 const oldBal=new Map(old.caisses.map(c=>[c.id,Number(c.solde)]));
 const expected=new Map(newer.caisses.map(c=>[c.id,oldBal.get(c.id)??0]));
 const stocks=new Map();
 const k=(m,a)=>m+'\u0001'+a;
 for(const [m,values] of Object.entries(old.stocks))for(const [a,q] of Object.entries(values))stocks.set(k(m,a),Number(q));
 for(const mv of newEvents){const amt=Number(mv.amount??0),q=Number(mv.quantity??0),src=mv.magSourceId,dst=mv.magDestId,art=mv.articleId;
  if(amt){if(mv.cashSourceId)expected.set(mv.cashSourceId,(expected.get(mv.cashSourceId)??0)-amt);if(mv.cashDestId)expected.set(mv.cashDestId,(expected.get(mv.cashDestId)??0)+amt)}
  if(src&&art&&q)stocks.set(k(src,art),(stocks.get(k(src,art))??0)-q);
  if(dst&&art&&q)stocks.set(k(dst,art),(stocks.get(k(dst,art))??0)+q);
 }
 for(const c of newer.caisses)ensure(Math.abs(c.solde-expected.get(c.id))<0.035,'Écart mouvements/caisse '+c.name);
 for(const [mag,st] of Object.entries(newer.stocks))for(const [art,q] of Object.entries(st))ensure(Math.abs(Number(q)-(stocks.get(k(mag,art))??0))<0.035,'Écart mouvements/stock : '+art);
 for(const [key,q] of stocks){const [mag,art]=key.split('\u0001');ensure(Math.abs(q-Number(newer.stocks[mag]?.[art]??0))<0.035,'Stock mouvement non rapproché')}
}
module.exports={emptyState,validate,validateChange};
