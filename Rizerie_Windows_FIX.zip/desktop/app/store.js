'use strict';
const {DatabaseSync}=require('node:sqlite');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {emptyState,validate,validateChange}=require('./state');
const Seasons=require('./seasons');
const {ensureSeasons}=Seasons;
const Annual=require('./annual');
const PBKDF2_ROUNDS=310000;
const utc=()=>new Date().toISOString();
function err(message){return {ok:false,error:String(message)}}
function sha(x){return crypto.createHash('sha256').update(x).digest('hex')}
function passwordHash(password,salt,rounds=PBKDF2_ROUNDS){return crypto.pbkdf2Sync(password,Buffer.from(salt,'hex'),rounds,32,'sha256').toString('hex')}
class Store {
 constructor(dataDir){this.dataDir=dataDir;this.dbPath=path.join(dataDir,'rizerie_pro.sqlite3');fs.mkdirSync(dataDir,{recursive:true});fs.mkdirSync(path.join(dataDir,'backups'),{recursive:true});this.loginAttempts=[];this.db=this.open(this.dbPath);this.init();}
 open(p,readOnly=false){const db=new DatabaseSync(p,{readOnly,timeout:10000});db.exec('PRAGMA busy_timeout=10000');if(!readOnly)db.exec('PRAGMA journal_mode=WAL');return db;}
 init(){this.db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, secret_hash TEXT NOT NULL, iterations INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS current_state (id INTEGER PRIMARY KEY CHECK (id=1), revision INTEGER NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, happened_at TEXT NOT NULL, username TEXT NOT NULL, operation TEXT NOT NULL, prior_revision INTEGER NOT NULL, next_revision INTEGER NOT NULL, before_sha256 TEXT NOT NULL, after_sha256 TEXT NOT NULL, detail TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS annual_closures (id INTEGER PRIMARY KEY AUTOINCREMENT, exercise_year INTEGER NOT NULL, next_year INTEGER NOT NULL, closed_at TEXT NOT NULL, archive_path TEXT NOT NULL, external_path TEXT NOT NULL, archive_sha256 TEXT NOT NULL, manifest_path TEXT NOT NULL, source_revision INTEGER NOT NULL, next_revision INTEGER NOT NULL, counts_json TEXT NOT NULL);`);
 if(!this.db.prepare('SELECT 1 FROM current_state LIMIT 1').get()){const obj=JSON.stringify(emptyState());this.db.prepare('INSERT INTO current_state (id,revision,payload,updated_at) VALUES (1,0,?,?)').run(obj,utc())}
  this.migrateSeasons();
  this.migrateExerciseYear();
 }
 migrateSeasons(){
  const row=this.db.prepare('SELECT revision,payload FROM current_state WHERE id=1').get();
  const original=JSON.parse(row.payload);const before=JSON.stringify(original);
  ensureSeasons(original,new Date().toISOString().slice(0,10));
  if(before===JSON.stringify(original))return;
  validate(original);
  this.backup('avant_migration_saisons');
  this.db.exec('BEGIN IMMEDIATE');
  try{this.db.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1').run(row.revision+1,JSON.stringify(original),utc());
   this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','MIGRATION_SAISONS',row.revision,row.revision+1,sha(before),sha(JSON.stringify(original)),'Création saisons initiales / anciennes rizeries');
   this.db.exec('COMMIT');
  }catch(ex){this.db.exec('ROLLBACK');throw ex}
 }
 migrateExerciseYear(){
  const row=this.db.prepare('SELECT revision,payload FROM current_state WHERE id=1').get();
  const original=JSON.parse(row.payload);
  if(Number.isSafeInteger(original.exerciseYear))return;
  original.exerciseYear=new Date().getFullYear();
  original.yearOpenedAt=original.yearOpenedAt||`${original.exerciseYear}-01-01T00:00:00.000Z`;
  validate(original);
  this.backup('avant_migration_exercice');
  const before=JSON.stringify(JSON.parse(row.payload)),after=JSON.stringify(original);
  this.db.exec('BEGIN IMMEDIATE');
  try{
   this.db.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1').run(row.revision+1,after,utc());
   this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','MIGRATION_EXERCICE',row.revision,row.revision+1,sha(before),sha(after),'Initialisation de l’exercice courant');
   this.db.exec('COMMIT');
  }catch(ex){this.db.exec('ROLLBACK');throw ex}
 }
 hasAdmin(){return !!this.db.prepare("SELECT 1 FROM users WHERE username='admin' LIMIT 1").get()}
 setup(password,confirm){if(this.hasAdmin())return err('Compte administrateur déjà créé.');if(typeof password!=='string'||password.length<10||password!==confirm)return err('Mot de passe de 10 caractères minimum et confirmation identique requis.');const salt=crypto.randomBytes(16).toString('hex');const hash=passwordHash(password,salt);this.db.prepare('INSERT INTO users(username,salt,secret_hash,iterations) VALUES (?,?,?,?)').run('admin',salt,hash,PBKDF2_ROUNDS);return {ok:true}}
 checkPassword(password){const now=Date.now();this.loginAttempts=this.loginAttempts.filter(t=>t>now-90000);if(this.loginAttempts.length>=7)return err('Trop de tentatives. Réessayez plus tard.');const u=this.db.prepare("SELECT * FROM users WHERE username='admin'").get();if(!u)return err('Compte administrateur non créé.');const supplied=passwordHash(String(password??''),u.salt,u.iterations);const a=Buffer.from(supplied,'hex'),b=Buffer.from(u.secret_hash,'hex');const ok=a.length===b.length&&crypto.timingSafeEqual(a,b);if(ok){this.loginAttempts=[];return {ok:true}}this.loginAttempts.push(now);return err('Mot de passe incorrect.')}
 getState(){const r=this.db.prepare('SELECT revision,payload,updated_at FROM current_state WHERE id=1').get();return {ok:true,revision:r.revision,data:JSON.parse(r.payload),saved_at:r.updated_at}}
 backup(label='manuel',destination){const file=destination||path.join(this.dataDir,'backups',new Date().toISOString().replace(/[:.]/g,'-')+'_'+label+'.sqlite3');fs.mkdirSync(path.dirname(file),{recursive:true});if(fs.existsSync(file))throw Error('Le fichier de sauvegarde existe déjà.');this.db.prepare('VACUUM INTO ?').run(file);return file;}
 save(body){
  if(!body||!Number.isSafeInteger(body.revision)||!body.data)return err('Révision ou données invalides.');
  try{
   ensureSeasons(body.data,new Date().toISOString().slice(0,10));
   validate(body.data);
   const old=this.getState();
   if(old.revision!==body.revision)return {ok:false,conflict:true,error:'Données modifiées ailleurs. Rechargez le formulaire.'};
   if(!body.import)validateChange(old.data,body.data);
   else this.backup('avant_import');
   const payload=JSON.stringify(body.data);
   const oldPayload=JSON.stringify(old.data);
   const kinds=(body.data.movements||[]).slice(0,Math.max(0,body.data.movements.length-old.data.movements.length)).map(x=>x.type).join(',').slice(0,700);
   this.db.exec('BEGIN IMMEDIATE');
   try{
    const r=this.db.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1 AND revision=?').run(old.revision+1,payload,utc(),old.revision);
    if(r.changes!==1)throw Error('Conflit de révision');
    this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin',body.import?'IMPORT':'WRITE',old.revision,old.revision+1,sha(oldPayload),sha(payload),kinds);
    this.db.exec('COMMIT');
   }catch(ex){this.db.exec('ROLLBACK');throw ex}
   return {ok:true,revision:old.revision+1,saved_at:utc()};
  }catch(ex){return err(ex.message)}
 }
 audit(){return this.db.prepare('SELECT happened_at,operation,prior_revision,next_revision,detail FROM audit_log ORDER BY id DESC LIMIT 100').all()}
 importOldBase(oldPath){
  if(path.resolve(oldPath)===path.resolve(this.dbPath))return err('La base actuelle est déjà utilisée.');
  let other;
  try{
   other=this.open(oldPath,true);
   const row=other.prepare('SELECT revision,payload FROM current_state WHERE id=1').get();
   if(!row)throw Error('Base SQLite V1.x incompatible : état absent');
   const next=JSON.parse(row.payload);ensureSeasons(next,new Date().toISOString().slice(0,10));validate(next);
   const current=this.getState();
   if(current.data.movements.length||current.data.prestations.length||current.data.sales.length||current.data.articles.length)throw Error('Import refusé : données actuelles déjà renseignées. Sauvegardez-les et utilisez Import JSON si vous souhaitez les remplacer.');
   const backed=this.backup('avant_migration');
   other.close();other=null;
   this.db.exec('BEGIN IMMEDIATE');
   try{this.db.prepare('UPDATE current_state SET revision=?, payload=?, updated_at=? WHERE id=1').run(current.revision+1,JSON.stringify(next),utc());this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','MIGRATION',current.revision,current.revision+1,sha(JSON.stringify(current.data)),sha(JSON.stringify(next)),path.basename(oldPath));this.db.exec('COMMIT');}catch(ex){this.db.exec('ROLLBACK');throw ex}
   return {ok:true,backup:backed,revision:current.revision+1};
  }catch(ex){return err(ex.message)}finally{try{other?.close()}catch(_){}}
 }
 previewAnnualClose(newYear){
  try{const data=this.getState().data;validate(data);return {ok:true,preview:Annual.preflight(data,Number(newYear),new Date())}}catch(ex){return err(ex.message)}
 }
 fileSha(file){return sha(fs.readFileSync(file));}
 verifyAnnualArchive(file,requireManifest=false){
  let db;
  try{
   if(!file||!fs.existsSync(file)||path.resolve(file)===path.resolve(this.dbPath))throw Error('Fichier archive introuvable ou non autorisé.');
   db=new DatabaseSync(file,{readOnly:true,timeout:10000});
   const integrity=db.prepare('PRAGMA integrity_check').all();
   if(!integrity.length||!Object.values(integrity[0]).includes('ok'))throw Error('Échec PRAGMA integrity_check.');
   const row=db.prepare('SELECT revision,payload FROM current_state WHERE id=1').get();
   if(!row)throw Error('Archive sans état SQLite.');
   const data=JSON.parse(row.payload);validate(data);
   const digest=this.fileSha(file),manifestPath=file+'.manifest.json';
   if(fs.existsSync(manifestPath)){
    const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
    if(manifest.product!=='Rizerie Service Pro'||manifest.type!=='ARCHIVE_ANNUELLE_IMMUABLE')throw Error('Le fichier n’est pas une archive annuelle Rizerie valide.');
    if(manifest.archiveSha256!==digest)throw Error('SHA-256 du manifeste incorrect.');
    if(manifest.exerciseYear!==data.exerciseYear)throw Error('Année du manifeste incohérente.');
    if(manifest.stateSha256!==sha(JSON.stringify(data)))throw Error('Empreinte de l’état archivé incorrecte.');
   }else if(requireManifest)throw Error('Manifeste annuel absent : archive non certifiée.');
   return {ok:true,file,exerciseYear:data.exerciseYear,revision:row.revision,sha256:digest,counts:Annual.operationCounts(data),master:{rizeries:data.sites.length,articles:data.articles.length,personnel:data.employees.length}};
  }catch(ex){return err(ex.message)}finally{try{db?.close()}catch(_){}}
 }
 listAnnualClosures(){return this.db.prepare('SELECT exercise_year,next_year,closed_at,archive_path,external_path,archive_sha256,manifest_path,source_revision,next_revision,counts_json FROM annual_closures ORDER BY exercise_year DESC, closed_at DESC').all().map(x=>({...x,counts:JSON.parse(x.counts_json)}));}
 closeYear(newYear,externalPath){
  let archiveDb;
  try{
   const old=this.getState();validate(old.data);const preview=Annual.preflight(old.data,Number(newYear),new Date());
   if(!preview.ok)return {ok:false,error:preview.issues.join('\n'),preview};
   if(!externalPath||!String(externalPath).toLowerCase().endsWith('.sqlite3')||path.resolve(externalPath)===path.resolve(this.dbPath)||fs.existsSync(externalPath))throw Error('Choisissez un nouveau chemin de sauvegarde .sqlite3 qui n’existe pas encore.');
   const year=preview.currentYear,yearEnd=preview.yearEnd,now=new Date(),closed=structuredClone(old.data);
   for(const site of closed.sites){if(Seasons.active(closed,site.id))Seasons.close(closed,site.id,yearEnd);}
   validate(closed);
   const next=Annual.makeNewYearState(closed,Number(newYear),now);
   const archiveDir=path.join(this.dataDir,'archives');fs.mkdirSync(archiveDir,{recursive:true});
   const stamp=now.toISOString().replace(/[:.]/g,'-');
   const archivePath=path.join(archiveDir,`Rizerie_Archive_${year}_${stamp}.sqlite3`);
   const internalManifest=archivePath+'.manifest.json',externalManifest=externalPath+'.manifest.json';
   if(fs.existsSync(archivePath)||fs.existsSync(internalManifest)||fs.existsSync(externalManifest))throw Error('Un fichier d’archive existe déjà avec ce nom.');
   const integrity=this.db.prepare('PRAGMA integrity_check').all();
   if(!integrity.length||!Object.values(integrity[0]).includes('ok'))throw Error('La base actuelle échoue au contrôle d’intégrité SQLite.');
   this.db.prepare('VACUUM INTO ?').run(archivePath);
   archiveDb=new DatabaseSync(archivePath,{timeout:10000});
   archiveDb.exec('PRAGMA journal_mode=DELETE');
   archiveDb.exec('BEGIN IMMEDIATE');
   try{
    archiveDb.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1').run(old.revision+1,JSON.stringify(closed),utc());
    archiveDb.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','CLOTURE_ANNUELLE',old.revision,old.revision+1,sha(JSON.stringify(old.data)),sha(JSON.stringify(closed)),`Clôture exercice ${year}`);
    archiveDb.exec('COMMIT');
   }catch(ex){archiveDb.exec('ROLLBACK');throw ex}
   archiveDb.close();archiveDb=null;
   const verified=this.verifyAnnualArchive(archivePath);if(!verified.ok)throw Error('Archive interne invalide : '+verified.error);
   const archiveSha=verified.sha256;
   fs.mkdirSync(path.dirname(externalPath),{recursive:true});
   fs.copyFileSync(archivePath,externalPath,fs.constants.COPYFILE_EXCL);
   if(this.fileSha(externalPath)!==archiveSha)throw Error('La copie externe ne correspond pas à l’archive interne (SHA-256).');
   const manifest={product:'Rizerie Service Pro',type:'ARCHIVE_ANNUELLE_IMMUABLE',exerciseYear:year,nextYear:Number(newYear),createdAt:now.toISOString(),archiveSha256:archiveSha,stateSha256:sha(JSON.stringify(closed)),sourceRevision:old.revision,closedRevision:old.revision+1,counts:Annual.operationCounts(closed),master:{rizeries:closed.sites.length,articles:closed.articles.length,personnel:closed.employees.length},restoreNote:'Restauration possible via Paramètres > Vérifier / restaurer une archive.'};
   const raw=JSON.stringify(manifest,null,2);
   fs.writeFileSync(internalManifest,raw,{flag:'wx'});fs.writeFileSync(externalManifest,raw,{flag:'wx'});
   try{fs.chmodSync(archivePath,0o444);fs.chmodSync(internalManifest,0o444);fs.chmodSync(externalPath,0o444);fs.chmodSync(externalManifest,0o444)}catch(_){}
   const finalVerify=this.verifyAnnualArchive(externalPath,true);if(!finalVerify.ok)throw Error('Archive externe invalide : '+finalVerify.error);
   const nextPayload=JSON.stringify(next),oldPayload=JSON.stringify(old.data);
   this.db.exec('BEGIN IMMEDIATE');
   try{
    const result=this.db.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1 AND revision=?').run(old.revision+1,nextPayload,utc(),old.revision);
    if(result.changes!==1)throw Error('Conflit de révision pendant la clôture annuelle.');
    this.db.prepare('INSERT INTO annual_closures(exercise_year,next_year,closed_at,archive_path,external_path,archive_sha256,manifest_path,source_revision,next_revision,counts_json) VALUES (?,?,?,?,?,?,?,?,?,?)').run(year,Number(newYear),utc(),archivePath,externalPath,archiveSha,internalManifest,old.revision,old.revision+1,JSON.stringify(Annual.operationCounts(closed)));
    // Les anciens journaux restent dans l'archive annuelle complète ; la base active démarre avec un audit propre.
    this.db.prepare('DELETE FROM audit_log').run();
    this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','NOUVELLE_ANNEE',old.revision,old.revision+1,sha(oldPayload),sha(nextPayload),`Exercice ${year} archivé; ouverture ${newYear}; archive SHA256 ${archiveSha}`);
    this.db.exec('COMMIT');
   }catch(ex){this.db.exec('ROLLBACK');throw ex}
   return {ok:true,exerciseYear:year,nextYear:Number(newYear),archivePath,externalPath,manifestPath:internalManifest,sha256:archiveSha,revision:old.revision+1,carriedStocks:next.openingStocks.length,carriedCash:next.caisses.length,counts:Annual.operationCounts(closed)};
  }catch(ex){try{archiveDb?.close()}catch(_){}return err(ex.message)}
 }
 restoreAnnualArchive(file){
  let source;
  try{
   const verified=this.verifyAnnualArchive(file,true);if(!verified.ok)throw Error(verified.error);
   source=new DatabaseSync(file,{readOnly:true,timeout:10000});
   const row=source.prepare('SELECT revision,payload FROM current_state WHERE id=1').get();
   const restored=JSON.parse(row.payload);validate(restored);
   const current=this.getState(),backup=this.backup('avant_restauration_annuelle');
   const before=JSON.stringify(current.data),after=JSON.stringify(restored);
   this.db.exec('BEGIN IMMEDIATE');
   try{
    this.db.prepare('UPDATE current_state SET revision=?,payload=?,updated_at=? WHERE id=1').run(current.revision+1,after,utc());
    const manifest=JSON.parse(fs.readFileSync(file+'.manifest.json','utf8'));
    this.db.prepare('INSERT INTO annual_closures(exercise_year,next_year,closed_at,archive_path,external_path,archive_sha256,manifest_path,source_revision,next_revision,counts_json) SELECT ?,?,?,?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM annual_closures WHERE archive_sha256=?)').run(manifest.exerciseYear,manifest.nextYear,manifest.createdAt,file,file,verified.sha256,file+'.manifest.json',manifest.sourceRevision,current.revision+1,JSON.stringify(verified.counts),verified.sha256);
    this.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)').run(utc(),'admin','RESTAURATION_ARCHIVE_ANNUELLE',current.revision,current.revision+1,sha(before),sha(after),`Restauration exercice ${restored.exerciseYear}; archive ${path.basename(file)}`);
    this.db.exec('COMMIT');
   }catch(ex){this.db.exec('ROLLBACK');throw ex}
   return {ok:true,exerciseYear:restored.exerciseYear,backup,revision:current.revision+1};
  }catch(ex){return err(ex.message)}finally{try{source?.close()}catch(_){}}
 }
 close(){this.db.close()}
}
module.exports={Store};
