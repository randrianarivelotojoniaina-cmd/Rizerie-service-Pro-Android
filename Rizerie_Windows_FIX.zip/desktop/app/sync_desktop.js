'use strict';
const fs=require('node:fs');
const {Store}=require('./store');
const {validate,validateChange}=require('./state');
const Sync=require('./sync_core');
const Codec=require('./sync_codec');
const crypto=require('node:crypto');
const SiteLink=require('./sync_site_link');
function ensure(b,msg){if(!b)throw Error(msg)}
function verifyPackage(p){
 ensure(p?.product==='Rizerie Service Pro'&&p.format===1,'Package Rizerie non reconnu');
 ensure(p.kind==='mobile-events'&&Array.isArray(p.events)&&p.events.length<=1000,'Paquet mobile invalide');
 ensure(String(p.deviceId||'').match(/^[a-zA-Z0-9_-]{6,90}$/),'Appareil non identifié');
 const ids=new Set();
 for(const e of p.events){
  ensure(e&&typeof e.id==='string'&&/^[a-f0-9-]{36}$/.test(e.id),'UUID événement incorrect');
  ensure(e.deviceId===p.deviceId,'Origine appareil incohérente');
  ensure(!ids.has(e.id),'Événement répété dans le fichier');ids.add(e.id);
  ensure(e.changes&&typeof e.changes==='object','Modifications invalides');
  ensure(!e.changes.extra?.exerciseYear,'Clôture annuelle interdite sur Android');
 }
 return p;
}
function initialize(db){db.exec(`CREATE TABLE IF NOT EXISTS sync_applied_events(event_id TEXT PRIMARY KEY, device_id TEXT NOT NULL, imported_at TEXT NOT NULL, decision TEXT NOT NULL, source_created_at TEXT);
 CREATE TABLE IF NOT EXISTS sync_import_log(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, device_id TEXT NOT NULL, imported INTEGER NOT NULL, skipped INTEGER NOT NULL, errors INTEGER NOT NULL, report_json TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sync_entity_alias(device_id TEXT NOT NULL,kind TEXT NOT NULL,source_id TEXT NOT NULL,target_id TEXT NOT NULL,linked_at TEXT NOT NULL,PRIMARY KEY(device_id,kind,source_id));`)}
function readAliases(db,deviceId){const result=new Map();for(const r of db.prepare('SELECT kind,source_id,target_id FROM sync_entity_alias WHERE device_id=?').all(deviceId))result.set(r.kind+':'+r.source_id,r.target_id);return result}
function exportMaster(store,pass){const doc=store.getState();initialize(store.db);const ids=store.db.prepare('SELECT event_id FROM sync_applied_events').all().map(x=>x.event_id);return Codec.encode({ackEventIds:ids,product:'Rizerie Service Pro',format:1,kind:'pc-snapshot',createdAt:new Date().toISOString(),revision:doc.revision,state:doc.data},pass)}
function readPackage(path,pass){ensure(fs.statSync(path).size<=24*1024*1024,'Fichier trop volumineux');return verifyPackage(Codec.decode(fs.readFileSync(path,'utf8'),pass))}
function preview(store,pkg){
 initialize(store.db);
 const applied=store.db.prepare('SELECT event_id FROM sync_applied_events WHERE event_id=?');
 let work=structuredClone(store.getState().data),aliases=readAliases(store.db,pkg.deviceId),events=[];
 for(const e of pkg.events){
  let status='ready',matches=[],error='',siteMatches=[];
  if(applied.get(e.id))status='already-imported';
  else try{
   const p=SiteLink.remap(work,e,aliases,false);
   if(p.needsLink){
    // Preview a *conditional* link only; it is never persisted without the explicit choice.
    const conditional=SiteLink.remap(work,e,aliases,true);
    const next=Sync.apply(work,conditional.event);validate(next);validateChange(work,next);
    work=next;for(const [k,v] of conditional.aliases)aliases.set(k,v);
    status='site-link';siteMatches=p.candidates;
   }
   else{
    matches=Sync.suspicious(p.event,work);
    const next=Sync.apply(work,p.event);validate(next);validateChange(work,next);
    if(matches.length)status='suspect';
    work=next;
   }
  }catch(ex){status='conflict';error=String(ex.message)}
  events.push({id:e.id,deviceId:e.deviceId,createdAt:e.createdAt,siteId:e.siteId||null,status,matches,siteMatches,error,operation:Sync.classify(e)});
 }
 return {ok:true,events,counts:events.reduce((x,e)=>(x[e.status]=(x[e.status]||0)+1,x),{})};
}
function importEvents(store,pkg,decisions){
 initialize(store.db);
 const base=store.getState();let work=structuredClone(base.data),accepted=[],skipped=[],conflicts=[];
 const exists=store.db.prepare('SELECT 1 FROM sync_applied_events WHERE event_id=?');
 const aliases=readAliases(store.db,pkg.deviceId),newAliases=[];
 for(const e of pkg.events){
  if(exists.get(e.id)){skipped.push({id:e.id,reason:'UUID déjà importé'});continue;}
  const decision=decisions?.[e.id];
  if(decision==='skip'){skipped.push({id:e.id,reason:'Ignoré par utilisateur'});continue;}
  try{
   const p=SiteLink.remap(work,e,aliases,decision==='link-site');
   if(p.needsLink){conflicts.push({id:e.id,reason:'Rizerie homonyme : confirmation explicite de liaison requise',siteMatches:p.candidates});continue;}
   const matches=Sync.suspicious(p.event,work);
   if(matches.length&&decision!=='accept'){conflicts.push({id:e.id,reason:'Doublon potentiel : décision utilisateur nécessaire',matches});continue;}
   const next=Sync.apply(work,p.event);validate(next);validateChange(work,next);
   work=next;accepted.push({original:e,decision:decision||'normal'});
   for(const [k,v] of p.aliases){aliases.set(k,v);const split=k.indexOf(':');newAliases.push({kind:k.slice(0,split),source:k.slice(split+1),target:v});}
  }catch(ex){conflicts.push({id:e.id,reason:String(ex.message)});}
 }
 if(!accepted.length)return {ok:true,imported:0,skipped,conflicts,revision:base.revision};
 const backup=store.backup('avant_import_android');
 const json=JSON.stringify(work),now=new Date().toISOString();
 store.db.exec('BEGIN IMMEDIATE');
 try{
  const row=store.db.prepare('UPDATE current_state SET revision=?, payload=?,updated_at=? WHERE id=1 AND revision=?').run(base.revision+1,json,now,base.revision);
  if(row.changes!==1)throw Error('Conflit de révision pendant import');
  for(const {original:e,decision} of accepted)
   store.db.prepare('INSERT INTO sync_applied_events(event_id,device_id,imported_at,decision,source_created_at) VALUES (?,?,?,?,?)')
    .run(e.id,e.deviceId,now,decision==='accept'?'confirmed-distinct':decision==='link-site'?'site-linked':'normal',e.createdAt||null);
  const insertAlias=store.db.prepare('INSERT INTO sync_entity_alias(device_id,kind,source_id,target_id,linked_at) VALUES (?,?,?,?,?)');
  for(const a of newAliases)insertAlias.run(pkg.deviceId,a.kind,a.source,a.target,now);
  store.db.prepare('INSERT INTO sync_import_log(date,device_id,imported,skipped,errors,report_json) VALUES (?,?,?,?,?,?)')
   .run(now,pkg.deviceId,accepted.length,skipped.length,conflicts.length,JSON.stringify({accepted:accepted.map(({original:e,decision})=>({id:e.id,decision})),skipped,conflicts,newAliases}));
  store.db.prepare('INSERT INTO audit_log(happened_at,username,operation,prior_revision,next_revision,before_sha256,after_sha256,detail) VALUES (?,?,?,?,?,?,?,?)')
   .run(now,'admin','SYNC_ANDROID',base.revision,base.revision+1,crypto.createHash('sha256').update(JSON.stringify(base.data)).digest('hex'),crypto.createHash('sha256').update(json).digest('hex'),`Appareil ${pkg.deviceId} : ${accepted.length} importés, ${newAliases.length} alias créés, ${skipped.length} ignorés, ${conflicts.length} conflits`);
  store.db.exec('COMMIT');
 }catch(ex){store.db.exec('ROLLBACK');throw ex}
 return {ok:true,imported:accepted.length,skipped,conflicts,revision:base.revision+1,backup,siteAliases:newAliases.length};
}
module.exports={initialize,exportMaster,readPackage,verifyPackage,preview,importEvents};
