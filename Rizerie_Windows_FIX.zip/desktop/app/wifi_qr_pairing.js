'use strict';
/* Pairing ONLY: no transfer/database access. Created on explicit user click. */
const os = require('node:os');
const http = require('node:http');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const TTL_MS = 5 * 60 * 1000;
const WIFI_RE = /wi[\s-]?fi|wireless|wlan/i;
const VIRTUAL_RE = /(virtual|vEthernet|docker|vmware|virtualbox|loopback|wi[\s-]?fi direct|bluetooth|hyper-v|wsl|\btap\b|\btun\b|\bvpn\b|local area connection\s*\*|connexion au réseau local\s*\*)/i;
let active = null;

function privateIPv4(ip) {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip || '');
  if (!m) return false;
  const a = m.slice(1).map(Number);
  if (a.some(x => x < 0 || x > 255)) return false;
  return a[0] === 10 || (a[0] === 172 && a[1] >= 16 && a[1] <= 31) || (a[0] === 192 && a[1] === 168);
}

function listPrivateInterfaces(networks = os.networkInterfaces()) {
  return Object.entries(networks).flatMap(([label, addrs]) => (addrs || []).map(x => ({ ...x, label })))
    .filter(i => (i.family === 'IPv4' || i.family === 4) && !i.internal && privateIPv4(i.address))
    .map(i => ({
      label: i.label,
      address: i.address,
      netmask: i.netmask || '',
      virtual: VIRTUAL_RE.test(i.label),
      wifi: WIFI_RE.test(i.label) && !/direct/i.test(i.label)
    }));
}

function defaultRouteIPv4() {
  if (process.platform !== 'win32') return null;
  try {
    const script = "$r = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Sort-Object RouteMetric,InterfaceMetric | Select-Object -First 1; if ($null -ne $r) { Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $r.InterfaceIndex -AddressState Preferred -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1 -ExpandProperty IPAddress }";
    const out = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
      encoding: 'utf8', windowsHide: true, timeout: 2500
    });
    const ip = String(out || '').trim().split(/\s+/)[0];
    return privateIPv4(ip) ? ip : null;
  } catch (_) {
    return null;
  }
}

function chooseLocalInterface(candidates, routeAddress = null) {
  const usable = (candidates || []).filter(i => !i.virtual && !VIRTUAL_RE.test(i.label || ''));
  const pool = usable.length ? usable : (candidates || []);
  const wifi = pool.filter(i => i.wifi || WIFI_RE.test(i.label || '') && !/direct/i.test(i.label || ''));

  // The PC is expected to connect to the phone's hotspot through its Wi-Fi adapter.
  if (wifi.length === 1) return wifi[0];
  if (wifi.length > 1) {
    const routedWifi = routeAddress ? wifi.find(i => i.address === routeAddress) : null;
    if (routedWifi) return routedWifi;
    throw Error('Plusieurs interfaces Wi-Fi privées sont actives : ' + wifi.map(i => `${i.label} (${i.address})`).join(' ; ') + '. Désactivez le Wi-Fi non utilisé puis recréez le QR Code.');
  }
  if (routeAddress) {
    const routed = pool.find(i => i.address === routeAddress);
    if (routed) return routed;
  }
  if (pool.length === 1) return pool[0];
  if (!pool.length) throw Error('Aucune adresse IPv4 privée utilisable. Connectez le PC au partage Wi-Fi du téléphone.');
  throw Error('Plusieurs interfaces réseau privées sont détectées : ' + pool.map(i => `${i.label} (${i.address})`).join(' ; ') + '. Impossible de choisir sans risque la bonne interface.');
}

function localInterface() {
  const candidates = listPrivateInterfaces();
  try { return chooseLocalInterface(candidates, null); }
  catch (firstError) {
    const routeAddress = defaultRouteIPv4();
    if (routeAddress) return chooseLocalInterface(candidates, routeAddress);
    throw firstError;
  }
}
function localIP() {
  return localInterface()?.address || null;
}

function stop() {
  if (!active) return;
  const old = active;
  active = null;
  clearTimeout(old.timer);
  try { old.server.close(); } catch (_) { }
}

function tokenMatches(received, expected) {
  const a = Buffer.from(String(received || ''), 'utf8');
  const b = Buffer.from(String(expected || ''), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function verifyLocalServer(host, port, token) {
  return new Promise((resolve, reject) => {
    const req = http.get({
      host, port, path: '/pair/status',
      headers: { 'X-Rizerie-Pair-Token': token, 'Connection': 'close' }
    }, res => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', chunk => { body += chunk; if (body.length > 4096) req.destroy(Error('Réponse locale trop volumineuse')); });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          if (res.statusCode !== 200 || data.product !== 'Rizerie Service Pro' || data.type !== 'pairing-check') {
            return reject(Error('Le contrôle HTTP local a retourné une réponse inattendue.'));
          }
          resolve(true);
        } catch (e) { reject(e); }
      });
    });
    req.setTimeout(2500, () => req.destroy(Error('Délai dépassé pendant le contrôle HTTP local.')));
    req.on('error', reject);
  });
}

async function start(ipOverride) {
  stop();
  const selected = ipOverride
    ? { label: ipOverride === '127.0.0.1' ? 'Loopback de test' : 'Adresse manuelle', address: ipOverride }
    : localInterface();
  const host = selected?.address;
  if (!host) throw Error('Adresse Wi-Fi locale (IPv4 privée) non trouvée. Connectez le PC au Wi-Fi.');
  if (host !== '127.0.0.1' && !privateIPv4(host)) throw Error('Adresse locale invalide');

  const token = crypto.randomBytes(24).toString('hex');
  const expiresAt = Date.now() + TTL_MS;
  const server = http.createServer((req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Connection', 'close');
    if (req.method !== 'GET' || req.url !== '/pair/status') { res.writeHead(404); res.end(); return; }
    if (Date.now() > expiresAt) { res.writeHead(410); res.end(); return; }
    if (!tokenMatches(req.headers['x-rizerie-pair-token'], token)) { res.writeHead(401); res.end(); return; }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ product: 'Rizerie Service Pro', type: 'pairing-check', version: 1, connection: 'local-wifi', transferStarted: false }));
  });
  server.headersTimeout = 5000;
  server.requestTimeout = 5000;
  server.keepAliveTimeout = 1000;
  server.maxHeadersCount = 16;

  try {
    await new Promise((resolve, reject) => {
      const onError = e => { server.off('listening', onListening); reject(e); };
      const onListening = () => { server.off('error', onError); resolve(); };
      server.once('error', onError);
      server.once('listening', onListening);
      // Port 0 asks Windows for an actually free port. The returned port is the only one advertised.
      server.listen({ port: 0, host: '0.0.0.0', exclusive: true });
    });
  } catch (e) {
    try { server.close(); } catch (_) { }
    throw Error('Impossible de démarrer le serveur QR Windows : ' + (e.message || e));
  }

  const bound = server.address();
  if (!bound || typeof bound === 'string' || !Number.isInteger(bound.port) || bound.port < 1) {
    try { server.close(); } catch (_) { }
    throw Error('Le système n’a pas retourné un port TCP valide pour le serveur QR.');
  }
  const port = bound.port;

  try {
    await verifyLocalServer(host, port, token);
  } catch (e) {
    try { server.close(); } catch (_) { }
    throw Error(`Serveur QR démarré, mais le contrôle local de ${host}:${port} a échoué : ${e.message || e}`);
  }

  const timer = setTimeout(() => { if (active?.server === server) stop(); }, TTL_MS + 1000);
  if (timer.unref) timer.unref();
  active = { server, timer, token, host, port };
  server.once('close', () => {
    if (active?.server === server) {
      clearTimeout(active.timer);
      active = null;
    }
  });

  const payload = 'RIZERIEPAIR:' + JSON.stringify({ type: 'RIZERIE_PAIR', version: 1, host, port, token, expiresAt });
  return {
    payload, host, port, expiresAt,
    interfaceName: selected.label,
    bindAddress: bound.address,
    verified: true,
    notice: 'Appairage uniquement : aucun transfert de données déclenché.'
  };
}

function qrSvg(payload) {
  const qrcode = require('qrcode-generator');
  const qr = qrcode(0, 'M');
  qr.addData(payload, 'Byte');
  qr.make();
  return qr.createSvgTag({ cellSize: 5, margin: 5, scalable: false });
}

module.exports = { start, stop, qrSvg, privateIPv4, localIP, listPrivateInterfaces, chooseLocalInterface, defaultRouteIPv4 };
