'use strict';
/* Explicit, auditable link of independently-created Android and PC site identities.
   An identical name is only a candidate, never authorization to merge.
   Alias maps are scoped to the originating device and persisted by sync_desktop. */
const Sync = require('./sync_core');
const clone = x => JSON.parse(JSON.stringify(x));
const normalized = s => String(s||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase('fr');
const aliasKey=(kind,id)=>`${kind}:${id}`;
const entities={sites:'sites',magasins:'magasins',caisses:'caisses',seasons:'seasons'};
const foreignKeys={
 siteId:'sites',magId:'magasins',magasinId:'magasins',magSourceId:'magasins',magDestId:'magasins',
 cashId:'caisses',caisseId:'caisses',cashSourceId:'caisses',cashDestId:'caisses',seasonId:'seasons'
};
function transformRow(row,kind,mappings){
 if(Array.isArray(row))return row.map(r=>transformRow(r,null,mappings));
 if(!row||typeof row!=='object')return row;
 const result={};
 for(const [k,v] of Object.entries(row)){
  let mapKind=foreignKeys[k];
  if(k==='id'&&kind&&entities[kind])mapKind=kind;
  if(mapKind&&v!=null)result[k]=mappings.get(aliasKey(mapKind,v))||v;
  else result[k]=transformRow(v,null,mappings);
 }
 return result;
}
function transform(event,mappings){
 const e=clone(event),c=e.changes;
 for(const [kind,items] of Object.entries(c.created||{})){
  c.created[kind]=items.filter(row=>!(entities[kind]&&mappings.has(aliasKey(kind,row.id))))
    .map(row=>transformRow(row,kind,mappings));
  if(!c.created[kind].length)delete c.created[kind];
 }
 for(const [kind,updates] of Object.entries(c.updated||{})){
  c.updated[kind]=updates.map(u=>({id:entities[kind]&&mappings.has(aliasKey(kind,u.id))
    ?'id:'+mappings.get(aliasKey(kind,u.id)):u.id,
    before:transformRow(u.before,kind,mappings),after:transformRow(u.after,kind,mappings)}));
 }
 for(const kind of ['stocks','stockValues']){
  for(const v of c.values?.[kind]||[])v.mag=mappings.get(aliasKey('magasins',v.mag))||v.mag;
 }
 for(const v of c.values?.balances||[])v.caisse=mappings.get(aliasKey('caisses',v.caisse))||v.caisse;
 for(const [kind,u] of Object.entries(c.extra||{})){
  // Unrelated settings are left intact. Never rewrite an arbitrary payload or free-text field.
  if(kind==='selectedSiteId'){
   u.before=mappings.get(aliasKey('sites',u.before))||u.before;
   u.after=mappings.get(aliasKey('sites',u.after))||u.after;
  }
 }
 return e;
}
function inspect(state,event,aliases=new Map()){
 const candidates=[];
 for(const raw of event.changes?.created?.sites||[]){
  if(aliases.has(aliasKey('sites',raw.id)))continue;
  const matches=(state.sites||[]).filter(s=>normalized(s.name)===normalized(raw.name));
  if(matches.length>1)throw Error('Plusieurs rizeries portent ce nom : rapprochement manuel nécessaire');
  if(matches.length===1){
   const target=matches[0];
   const foreign=(event.changes?.created?.movements||[]).length||
     (event.changes?.created?.prestations||[]).length||
     (event.changes?.values?.stocks||[]).some(v=>v.delta)||
     (event.changes?.values?.stockValues||[]).some(v=>v.delta)||
     (event.changes?.values?.balances||[]).some(v=>v.delta);
   if(foreign)throw Error('Ce site inclut des mouvements/stock initial : rapprochement comptable manuel obligatoire avant liaison');
   candidates.push({sourceId:raw.id,sourceName:raw.name,targetId:target.id,targetName:target.name,
     sameId:raw.id===target.id,
     differences:['tarif','startDate'].filter(k=>String(raw[k]??'')!==String(target[k]??''))});
  }
 }
 return candidates;
}
function propose(state,event,aliases=new Map()){
 const candidates=inspect(state,event,aliases);
 if(!candidates.length)return {event:transform(event,aliases),aliases:new Map(),candidates:[]};
 const mappings=new Map(aliases),newAliases=new Map();
 const register=(kind,sourceId,targetId)=>{
  const k=aliasKey(kind,sourceId);
  if(mappings.has(k)&&mappings.get(k)!==targetId)throw Error('Alias incompatible : '+k);
  if(!mappings.has(k)){mappings.set(k,targetId);newAliases.set(k,targetId);}
 };
 for(const cand of candidates){
  register('sites',cand.sourceId,cand.targetId);
  for(const kind of ['magasins','caisses']){
   const source=(event.changes?.created?.[kind]||[]).filter(row=>row.siteId===cand.sourceId);
   const dest=(state[kind]||[]).filter(row=>row.siteId===cand.targetId);
   if(source.length!==1||dest.length!==1)throw Error('Magasin ou caisse liée non unique : contrôle manuel requis');
   register(kind,source[0].id,dest[0].id);
  }
  for(const season of (event.changes?.created?.seasons||[]).filter(x=>x.siteId===cand.sourceId)){
   const targets=(state.seasons||[]).filter(x=>x.siteId===cand.targetId&&x.number===season.number);
   if(targets.length!==1)throw Error('Saison différente ou absente sur PC : liaison manuelle nécessaire');
   register('seasons',season.id,targets[0].id);
  }
 }
 return {event:transform(event,mappings),aliases:newAliases,candidates};
}
function remap(state,event,knownAliases=new Map(),allowLink=false){
 const possible=inspect(state,event,knownAliases);
 if(possible.length&&!allowLink)return {needsLink:true,candidates:possible};
 const proposed=propose(state,event,knownAliases);
 return {...proposed,needsLink:false};
}
module.exports={remap,normalized,aliasKey,transform};
