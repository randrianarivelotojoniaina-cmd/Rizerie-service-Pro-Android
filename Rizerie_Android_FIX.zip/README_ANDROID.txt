RIZERIE SERVICE PRO V2.7 — CORRECTIF RÉSEAU QR ANDROID (SOURCE)

PÉRIMÈTRE
- Scanner QR natif Android conservé.
- Vérification du QR, de l'adresse IPv4 privée, du port, du jeton et de l'expiration.
- Délai de connexion et de lecture HTTP porté à 10 secondes pour tolérer les partages de connexion plus lents.
- Messages différenciés pour QR expiré, jeton invalide, connexion TCP impossible et délai dépassé.
- Le scan vérifie uniquement que le PC répond. Il ne déclenche aucun transfert et n'accède pas à la base SQLite.

TESTS
- Test statique du manifeste, des permissions caméra, du scanner QR et des délais réseau.
- La compilation APK et le test sur téléphone réel restent à exécuter via GitHub Actions puis sur l'appareil.

LIMITES
- Le transfert Wi-Fi direct bidirectionnel des données métier n'est pas implémenté dans cette version.
- Les exports/imports .rpsync existants restent séparés.
- Ne pas remplacer ni réinitialiser la base SQLite Android ou Windows pour tester le QR.
