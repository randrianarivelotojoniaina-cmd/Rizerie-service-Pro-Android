'use strict';
const assert=require('node:assert/strict');
const http=require('node:http');
const p=require('../desktop/app/wifi_qr_pairing');
function get(host,port,token){return new Promise((resolve,reject)=>{
 const req=http.get({host,port,path:'/pair/status',headers:{'X-Rizerie-Pair-Token':token}},res=>{
  let body='';res.on('data',c=>body+=c);res.on('end',()=>resolve({status:res.statusCode,body}));
 });req.on('error',reject);
});}
(async()=>{
 assert.equal(p.privateIPv4('192.168.0.20'),true);
 assert.equal(p.privateIPv4('10.5.5.9'),true);
 assert.equal(p.privateIPv4('172.20.1.1'),true);
 assert.equal(p.privateIPv4('8.8.8.8'),false);
 assert.equal(p.privateIPv4('127.0.0.1'),false);
 let r=await p.start('127.0.0.1');
 assert(r.payload.startsWith('RIZERIEPAIR:'));
 const decoded=JSON.parse(r.payload.slice('RIZERIEPAIR:'.length));
 assert.equal(decoded.type,'RIZERIE_PAIR');
 assert.equal(decoded.version,1);
 assert(decoded.expiresAt > Date.now());
 assert.equal((await get('127.0.0.1',r.port,'wrong')).status,404);
 let good=await get('127.0.0.1',r.port,decoded.token);
 assert.equal(good.status,200);
 assert.equal(JSON.parse(good.body).transferStarted,false);
 assert.equal(JSON.parse(good.body).type,'pairing-check');
 p.stop();
 console.log('13 tests QR pairing OK — aucun transfert de données');
})().catch(e=>{p.stop();console.error(e);process.exitCode=1});
