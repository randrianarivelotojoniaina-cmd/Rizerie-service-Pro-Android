RIZERIE SERVICE PRO — V2.7 Correctif association Rizeries Windows (SOURCE)

Objectif : résoudre « Conflit identifiant sites id:r1 » quand une seule et même
Rizerie a été créée indépendamment sur le PC et sur Android.

Fichiers modifiés/ajoutés :
  desktop/app/sync_site_link.js (nouveau)
  desktop/app/sync_desktop.js
  desktop/app/index.html
  desktop/app/...(sources complètes conservées)

Comportement :
- Un nom similaire déclenche une PROPOSITION, pas une fusion silencieuse.
- L'utilisateur doit explicitement choisir « Confirmer : même Rizerie ».
- L'identifiant Android est lié à l'identifiant PC et la liaison persistée en SQLite,
  de manière distincte pour chaque téléphone (device_id).
- Le magasin, la caisse et la saison liés sont rapprochés avec contrôles de cardinalité.
- Les dates/paramètres du PC restent inchangés : différences affichées.
- Les événements déjà importés (UUID) restent ignorés.
- Les mouvements/stock initial simultanés à la création du site sont BLOQUÉS
  et exigent un rapprochement comptable, sans double comptabilisation.
- Une sauvegarde SQLite est créée avant tout import effectif.

TESTS EFFECTUÉS (Node.js 22 local) :
- Liaison d'une Rizerie source r1 vers une Rizerie PC r8 (test), une seule Rizerie après import.
- Réécriture des références liées et import d'une prestation ultérieure.
- Test collision avec nom différent, refus de fusion.
- Test création contenant un mouvement, refus sans examen.
- Persistance des alias SQLite, audit et non-réimport d'UUID.
- Test du serveur QR local ; aucune donnée transférée lors du simple scan.

IMPORTANT :
- ZIP contient les SOURCES Windows, pas un nouveau .exe compilé.
- L'application Windows V2.5 actuellement installée ne bénéficie PAS de ce correctif
  tant que son code n'a pas été mis à jour / empaqueté et testé.
- Ne pas remplacer un fichier sqlite3 de production ni supprimer des données.
- Ne pas utiliser un import en cours sur la vraie base sans sauvegarde et validation.
- Le lien Wi-Fi QR reste un appairage; pas de fusion directe réseau automatique.
