'use strict';
/* Pairing ONLY: no transfer/database access. Created on explicit user click. */
const os = require('node:os');
const http = require('node:http');
const crypto = require('node:crypto');
const TTL_MS = 5 * 60 * 1000;
let active = null;
function privateIPv4(ip){
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip || '');
  if(!m) return false;
  const a=m.slice(1).map(Number);
  if(a.some(x=>x>255)) return false;
  return a[0]===10 || (a[0]===172 && a[1]>=16 && a[1]<=31) || (a[0]===192 && a[1]===168);
}
function localIP(){
  const all=Object.entries(os.networkInterfaces()).flatMap(([label,addrs])=>(addrs||[]).map(x=>({...x,label})));
  const candidates=all.filter(i=>i.family==='IPv4'&&!i.internal&&privateIPv4(i.address));
  candidates.sort((a,b)=>Number(/(virtual|vEthernet|docker|vmware|loopback)/i.test(a.label))-Number(/(virtual|vEthernet|docker|vmware|loopback)/i.test(b.label)));
  return candidates[0]?.address || null;
}
function stop(){if(active){clearTimeout(active.timer);active.server.close();active=null;}}
async function start(ipOverride){
  stop();
  const host=ipOverride||localIP();
  if(!host) throw Error('Adresse Wi-Fi locale (IPv4 privée) non trouvée. Connectez le PC au Wi-Fi.');
  // A fixed IP is only allowed in tests on loopback.
  if(host!=='127.0.0.1'&&!privateIPv4(host))throw Error('Adresse locale invalide');
  const token=crypto.randomBytes(24).toString('hex'), expiresAt=Date.now()+TTL_MS;
  const server=http.createServer((req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
    if(req.method!=='GET'||req.url!=='/pair/status'||req.headers['x-rizerie-pair-token']!==token||Date.now()>expiresAt){res.writeHead(404);res.end();return;}
    res.writeHead(200,{'Content-Type':'application/json; charset=utf-8'});
    res.end(JSON.stringify({product:'Rizerie Service Pro',type:'pairing-check',version:1,connection:'local-wifi',transferStarted:false}));
  });
  try{
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'0.0.0.0',resolve)});
  }catch(e){try{server.close()}catch(_){}throw e;}
  const port=server.address().port;
  const timer=setTimeout(()=>{if(active?.server===server)stop()},TTL_MS+1000);
  if(timer.unref)timer.unref();
  active={server,timer,token};
  const payload='RIZERIEPAIR:'+JSON.stringify({type:'RIZERIE_PAIR',version:1,host,port,token,expiresAt});
  return {payload,host,port,expiresAt,notice:'Appairage uniquement : aucun transfert de données déclenché.'};
}
function qrSvg(payload){
  const qrcode=require('qrcode-generator');
  const qr=qrcode(0,'M');qr.addData(payload,'Byte');qr.make();
  return qr.createSvgTag({cellSize:5,margin:5,scalable:false});
}
module.exports={start,stop,qrSvg,privateIPv4,localIP};
