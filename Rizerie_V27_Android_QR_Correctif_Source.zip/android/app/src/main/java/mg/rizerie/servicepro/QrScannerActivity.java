package mg.rizerie.servicepro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;
import java.util.Collections;
import java.util.List;

/** QR reader embedded inside this application; no external scanner app is required. */
public final class QrScannerActivity extends Activity {
  public static final String RESULT_QR = "rizerie_qr_payload";
  public static final String RESULT_ERROR = "rizerie_qr_error";
  private DecoratedBarcodeView scanner;
  private boolean completed = false;
  private static final String TAG = "RizerieQrScanner";

  private void finishWithError(String detail) {
    if (completed) return;
    completed = true;
    Intent result = new Intent();
    result.putExtra(RESULT_ERROR, detail);
    setResult(RESULT_CANCELED, result);
    finish();
  }
  private void finishWithQr(String payload) {
    if (completed) return;
    completed = true;
    Intent result = new Intent();
    result.putExtra(RESULT_QR, payload);
    setResult(RESULT_OK, result);
    finish();
  }
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    try {
      if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
        finishWithError("Autorisation caméra refusée");return;
      }
      LinearLayout root = new LinearLayout(this);
      root.setOrientation(LinearLayout.VERTICAL);
      root.setBackgroundColor(0xff071c34);
      TextView text = new TextView(this);
      text.setText("Scanner le QR Code Rizerie affiché sur le PC");
      text.setTextSize(18);text.setTextColor(0xffffffff);text.setGravity(Gravity.CENTER);
      text.setPadding(18,18,18,18);
      root.addView(text,new LinearLayout.LayoutParams(-1,-2));
      scanner = new DecoratedBarcodeView(this);
      scanner.getBarcodeView().setDecoderFactory(
        new DefaultDecoderFactory(Collections.singletonList(BarcodeFormat.QR_CODE)));
      root.addView(scanner,new LinearLayout.LayoutParams(-1,0,1));
      Button cancel = new Button(this);
      cancel.setText("Annuler le scan");
      cancel.setOnClickListener(v -> finishWithError("Scan annulé"));
      root.addView(cancel,new LinearLayout.LayoutParams(-1,-2));
      setContentView(root);
      scanner.decodeSingle(new BarcodeCallback() {
        @Override public void barcodeResult(BarcodeResult result) {
          if (result != null && result.getText() != null) finishWithQr(result.getText());
        }
        @Override public void possibleResultPoints(List<ResultPoint> points) { }
      });
    } catch (Exception ex) {
      Log.e(TAG,"Impossible d'initialiser la lecture QR",ex);
      finishWithError("Scanner indisponible : " + ex.getClass().getSimpleName());
    } catch (LinkageError err) {
      Log.e(TAG,"Bibliothèque QR indisponible",err);
      finishWithError("Bibliothèque scanner indisponible : " + err.getClass().getSimpleName());
    }
  }
  @Override protected void onResume() {
    super.onResume();
    if (scanner != null && !completed) {
      try { scanner.resume(); }
      catch(Exception ex){Log.e(TAG,"Erreur caméra",ex);finishWithError("Impossible d'ouvrir la caméra : "+ex.getClass().getSimpleName());}
      catch(LinkageError err){Log.e(TAG,"Erreur scanner",err);finishWithError("Scanner non disponible : "+err.getClass().getSimpleName());}
    }
  }
  @Override protected void onPause() {
    if(scanner != null){try{scanner.pause();}catch(Exception ex){Log.w(TAG,"Pause caméra",ex);}}
    super.onPause();
  }
  @Override public void onBackPressed(){finishWithError("Scan annulé");}
}
