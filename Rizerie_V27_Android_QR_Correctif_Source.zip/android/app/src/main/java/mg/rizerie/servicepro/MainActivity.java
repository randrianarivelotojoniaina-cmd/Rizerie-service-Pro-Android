package mg.rizerie.servicepro;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.util.Log;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.InetAddress;
import java.util.regex.Pattern;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.UUID;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
  private WebView web;private RizerieDatabase db;
  private static final int EXPORT=210,IMPORT=211,SCAN_QR=212,CAMERA_REQUEST=213;
  private String pendingPass="";private String pendingExport="";private boolean unlocked=false;
  @Override public void onCreate(Bundle saved){super.onCreate(saved);db=new RizerieDatabase(this);
    web=new WebView(this);setContentView(web);
    WebSettings st=web.getSettings();st.setJavaScriptEnabled(true);st.setDomStorageEnabled(true);st.setAllowFileAccess(true);st.setAllowFileAccessFromFileURLs(false);st.setAllowUniversalAccessFromFileURLs(false);st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){return !request.getUrl().toString().startsWith("file:///android_asset/");}});
    web.addJavascriptInterface(new Bridge(),"AndroidRizerie");web.loadUrl("file:///android_asset/login.html");
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  void jsEvent(String result){runOnUiThread(()->web.evaluateJavascript("window.rizerieMobileResult && window.rizerieMobileResult("+JSONObject.quote(result)+")",null));}
  void jsPairEvent(JSONObject result){runOnUiThread(()->web.evaluateJavascript(
    "window.rizerieMobilePairResult && window.rizerieMobilePairResult("+result.toString()+")",null));}
  void pairFromQr(String raw){
    new Thread(()->{
      JSONObject report=new JSONObject();
      try{
        if(raw==null||!raw.startsWith("RIZERIEPAIR:"))throw new Exception("QR Code Rizerie non reconnu");
        JSONObject qr=new JSONObject(raw.substring("RIZERIEPAIR:".length()));
        if(!"RIZERIE_PAIR".equals(qr.optString("type"))||qr.optInt("version")!=1)throw new Exception("QR non compatible");
        String host=qr.getString("host"),token=qr.getString("token");int port=qr.getInt("port");
        long exp=qr.getLong("expiresAt");
        if(!host.matches("[0-9.]{7,15}")||port<1024||port>65535||!token.matches("[0-9a-f]{48}"))throw new Exception("QR de connexion invalide");
        String[] a=host.split("\\.");
        if(a.length!=4)throw new Exception("Adresse PC invalide");
        int[] v=new int[4];for(int i=0;i<4;i++){v[i]=Integer.parseInt(a[i]);if(v[i]>255)throw new Exception("Adresse IP invalide");}
        if(!(v[0]==10||(v[0]==172&&v[1]>=16&&v[1]<=31)||(v[0]==192&&v[1]==168)))throw new Exception("Adresse hors réseau privé local");
        if(System.currentTimeMillis()>exp)throw new Exception("QR expiré : actualisez sur le PC");
        HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+":"+port+"/pair/status").openConnection();
        c.setRequestMethod("GET");c.setConnectTimeout(3500);c.setReadTimeout(3500);
        c.setRequestProperty("X-Rizerie-Pair-Token",token);
        try{
          if(c.getResponseCode()!=200)throw new Exception("Vérification PC refusée ou QR expiré");
          java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();
          try(InputStream in=c.getInputStream()){byte[] buf=new byte[2048];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>4096)throw new Exception("Réponse PC invalide");}}
          JSONObject answer=new JSONObject(out.toString("UTF-8"));
          if(!"Rizerie Service Pro".equals(answer.optString("product"))||!"pairing-check".equals(answer.optString("type")))throw new Exception("PC non reconnu");
        }finally{c.disconnect();}
        report.put("ok",true).put("host",host).put("status","PC joignable sur Wi-Fi local. Aucun transfert de données n’a commencé.");
      }catch(Exception err){try{report.put("ok",false).put("error",err.getMessage());}catch(Exception ignored){}}
      jsPairEvent(report);
    },"rizerie-pairing-check").start();
  }
  void launchQrScanner(){
    try {
      if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)==false){
        JSONObject r=new JSONObject();r.put("ok",false).put("error","Aucune caméra disponible sur cet appareil");jsPairEvent(r);return;
      }
      if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
        requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);return;
      }
      startActivityForResult(new Intent(this,QrScannerActivity.class),SCAN_QR);
    } catch(Exception ex){
      Log.e("RizerieQR","Erreur démarrage scanner",ex);
      try{JSONObject r=new JSONObject();r.put("ok",false).put("error","Scanner impossible : "+ex.getClass().getSimpleName());jsPairEvent(r);}catch(Exception ignored){}
    } catch(LinkageError err){
      Log.e("RizerieQR","Bibliothèque scanner manquante",err);
      try{JSONObject r=new JSONObject();r.put("ok",false).put("error","Bibliothèque QR non disponible");jsPairEvent(r);}catch(Exception ignored){}
    }
  }
  @Override public void onRequestPermissionsResult(int request,String[] perms,int[] grants){
    super.onRequestPermissionsResult(request,perms,grants);
    if(request==CAMERA_REQUEST){
      if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)launchQrScanner();
      else try{JSONObject r=new JSONObject();r.put("ok",false).put("error","Autorisation caméra refusée");jsPairEvent(r);}catch(Exception ignored){}
    }
  }
  class Bridge{
    @JavascriptInterface public String call(String op,String arg){
      try{JSONObject a=new JSONObject(arg==null?"{}":arg);
        if("scanPairQr".equals(op)){
          runOnUiThread(()->launchQrScanner());
          return new JSONObject().put("ok",true).put("pending",true).toString();
        }
        if("uuid".equals(op))return new JSONObject().put("ok",true).put("id",UUID.randomUUID().toString()).toString();
        if("device".equals(op))return new JSONObject().put("ok",true).put("deviceId",db.deviceId()).put("pending",db.pending()).toString();
        if("configured".equals(op))return new JSONObject().put("ok",true).put("configured",db.configured()).toString();
        if("setup".equals(op)){JSONObject r=db.setup(a);unlocked=true;return r.toString();}
        if("login".equals(op)){JSONObject r=db.login(a);unlocked=true;return r.toString();}
        if("logout".equals(op)){unlocked=false;runOnUiThread(()->web.loadUrl("file:///android_asset/login.html"));return new JSONObject().put("ok",true).toString();}
        if(!unlocked)throw new Exception("Connectez-vous pour accéder aux données");
        if("state".equals(op))return db.state().toString();
        if("save".equals(op))return db.save(a).toString();
        if("export".equals(op)){
          pendingPass=a.getString("pass");pendingExport=CryptoPack.encrypt(db.events(),pendingPass);
          runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"Rizerie_Android_"+db.deviceId()+".rpsync");startActivityForResult(i,EXPORT);});
          return new JSONObject().put("ok",true).put("pending",true).toString();
        }
        if("import".equals(op)){
          pendingPass=a.getString("pass");
          runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,IMPORT);});
          return new JSONObject().put("ok",true).put("pending",true).toString();
        }
        throw new Exception("Opération Android inconnue");
      }catch(Exception e){try{return new JSONObject().put("ok",false).put("error",e.getMessage()).toString();}catch(Exception x){return "{\"ok\":false}";}}
    }
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request==SCAN_QR){
      String payload=data==null?null:data.getStringExtra(QrScannerActivity.RESULT_QR);
      if(result==RESULT_OK&&payload!=null){pairFromQr(payload);}else{
        JSONObject j=new JSONObject();try{j.put("ok",false).put("error",data==null?"Scan annulé":data.getStringExtra(QrScannerActivity.RESULT_ERROR));}catch(Exception ignored){}
        jsPairEvent(j);
      }
      return;
    }
    if(result!=RESULT_OK||data==null||data.getData()==null){jsEvent("Opération annulée");return;}
    Uri uri=data.getData();try{
      if(request==EXPORT){try(OutputStream o=getContentResolver().openOutputStream(uri,"wt")){o.write(pendingExport.getBytes(StandardCharsets.UTF_8));o.flush();}jsEvent("Export Android effectué. Transférez le fichier .rpsync vers le PC.");}
      else if(request==IMPORT){ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0){bytes.write(buf,0,n);if(bytes.size()>24000000)throw new Exception("Fichier trop volumineux");}}
        JSONObject p=CryptoPack.decrypt(bytes.toString("UTF-8"),pendingPass);db.importMaster(p);jsEvent("Base PC importée avec succès. Redémarrez l'application pour actualiser les écrans.");}
    }catch(Exception e){jsEvent("Erreur de synchronisation : "+e.getMessage());}
    finally{pendingPass="";pendingExport="";}
  }
  @Override protected void onDestroy(){try{db.close();}catch(Exception ignored){}super.onDestroy();}
}
