RIZERIE SERVICE PRO — V2.7 Correctif QR Android (SOURCE)

Objectif : réduire les crashs lors du lancement du scanner QR.
- Scanner interne (QrScannerActivity) à la place de l'ancien lancement IntentIntegrator.
- Autorisation caméra demandée explicitement avant ouverture.
- En cas d'erreur au démarrage, message retourné à l'interface plutôt que crash du lancement.
- Le QR ne déclenche aucun transfert automatique. Il ne vérifie que l'appairage PC.
- Aucun changement de la base SQLite, des opérations ou des fichiers .rpsync.

TESTS EFFECTUÉS :
- Vérifications statiques de la configuration scanner et JavaScript.
TESTS NON EFFECTUÉS :
- Compilation Gradle/installation sur téléphone et analyse logcat sur l'appareil touché.
- Fonctionnement effectif de la caméra et du scanner dans toutes les versions Android.

UTILISATION :
1) Sauvegarder les données avant mise à jour.
2) Mettre le ZIP source à la racine du repository GitHub (sans extraire).
3) Copier le contenu de GITHUB_BUILD_APK_QR_CORRECTIF.yml dans .github/workflows/build-apk.yml.
4) Lancer manuellement Actions > Run workflow.
5) Tester l'APK de débogage sur un appareil avec données fictives seulement.

Note: le transfert Wi-Fi direct bidirectionnel n'est PAS implémenté par cette correction.
