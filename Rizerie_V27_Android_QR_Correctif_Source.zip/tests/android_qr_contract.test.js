'use strict';
// Source-level smoke test. Not an Android runtime test.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const root='android/app/src/main/';
const manifest=fs.readFileSync(root+'AndroidManifest.xml','utf8');
const main=fs.readFileSync(root+'java/mg/rizerie/servicepro/MainActivity.java','utf8');
const scanner=fs.readFileSync(root+'java/mg/rizerie/servicepro/QrScannerActivity.java','utf8');
const gradle=fs.readFileSync('android/app/build.gradle','utf8');
assert(manifest.includes('android.permission.CAMERA'));
assert(manifest.includes('android:name=".QrScannerActivity"'));
assert(main.includes('requestPermissions(new String[]{Manifest.permission.CAMERA}'));
assert(main.includes('QrScannerActivity.RESULT_QR'));
assert(scanner.includes('decodeSingle('));
assert(scanner.includes('finishWithError('));
assert(gradle.includes('zxing-android-embedded:4.3.0'));
assert(!main.includes('new IntentIntegrator('),'Old scanner launch should be removed');
console.log('OK: manifest, camera permission, QR callback, error path and dependency present (static only)');
