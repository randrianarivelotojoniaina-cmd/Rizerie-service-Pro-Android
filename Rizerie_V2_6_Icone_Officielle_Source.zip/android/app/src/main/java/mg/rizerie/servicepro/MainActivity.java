package mg.rizerie.servicepro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.view.View;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.UUID;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
  private WebView web;private RizerieDatabase db;
  private static final int EXPORT=210,IMPORT=211;
  private String pendingPass="";private String pendingExport="";private boolean unlocked=false;
  @Override public void onCreate(Bundle saved){super.onCreate(saved);db=new RizerieDatabase(this);
    web=new WebView(this);setContentView(web);
    WebSettings st=web.getSettings();st.setJavaScriptEnabled(true);st.setDomStorageEnabled(true);st.setAllowFileAccess(true);st.setAllowFileAccessFromFileURLs(false);st.setAllowUniversalAccessFromFileURLs(false);st.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){return !request.getUrl().toString().startsWith("file:///android_asset/");}});
    web.addJavascriptInterface(new Bridge(),"AndroidRizerie");web.loadUrl("file:///android_asset/login.html");
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  void jsEvent(String result){runOnUiThread(()->web.evaluateJavascript("window.rizerieMobileResult && window.rizerieMobileResult("+JSONObject.quote(result)+")",null));}
  class Bridge{
    @JavascriptInterface public String call(String op,String arg){
      try{JSONObject a=new JSONObject(arg==null?"{}":arg);
        if("uuid".equals(op))return new JSONObject().put("ok",true).put("id",UUID.randomUUID().toString()).toString();
        if("device".equals(op))return new JSONObject().put("ok",true).put("deviceId",db.deviceId()).put("pending",db.pending()).toString();
        if("configured".equals(op))return new JSONObject().put("ok",true).put("configured",db.configured()).toString();
        if("setup".equals(op)){JSONObject r=db.setup(a);unlocked=true;return r.toString();}
        if("login".equals(op)){JSONObject r=db.login(a);unlocked=true;return r.toString();}
        if("logout".equals(op)){unlocked=false;runOnUiThread(()->web.loadUrl("file:///android_asset/login.html"));return new JSONObject().put("ok",true).toString();}
        if(!unlocked)throw new Exception("Connectez-vous pour accéder aux données");
        if("state".equals(op))return db.state().toString();
        if("save".equals(op))return db.save(a).toString();
        if("export".equals(op)){
          pendingPass=a.getString("pass");pendingExport=CryptoPack.encrypt(db.events(),pendingPass);
          runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"Rizerie_Android_"+db.deviceId()+".rpsync");startActivityForResult(i,EXPORT);});
          return new JSONObject().put("ok",true).put("pending",true).toString();
        }
        if("import".equals(op)){
          pendingPass=a.getString("pass");
          runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,IMPORT);});
          return new JSONObject().put("ok",true).put("pending",true).toString();
        }
        throw new Exception("Opération Android inconnue");
      }catch(Exception e){try{return new JSONObject().put("ok",false).put("error",e.getMessage()).toString();}catch(Exception x){return "{\"ok\":false}";}}
    }
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(result!=RESULT_OK||data==null||data.getData()==null){jsEvent("Opération annulée");return;}
    Uri uri=data.getData();try{
      if(request==EXPORT){try(OutputStream o=getContentResolver().openOutputStream(uri,"wt")){o.write(pendingExport.getBytes(StandardCharsets.UTF_8));o.flush();}jsEvent("Export Android effectué. Transférez le fichier .rpsync vers le PC.");}
      else if(request==IMPORT){ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0){bytes.write(buf,0,n);if(bytes.size()>24000000)throw new Exception("Fichier trop volumineux");}}
        JSONObject p=CryptoPack.decrypt(bytes.toString("UTF-8"),pendingPass);db.importMaster(p);jsEvent("Base PC importée avec succès. Redémarrez l'application pour actualiser les écrans.");}
    }catch(Exception e){jsEvent("Erreur de synchronisation : "+e.getMessage());}
    finally{pendingPass="";pendingExport="";}
  }
  @Override protected void onDestroy(){try{db.close();}catch(Exception ignored){}super.onDestroy();}
}
