RIZERIE SERVICE PRO V2.5 - COMPILATION APK VIA GITHUB ACTIONS

Ce ZIP contient UNIQUEMENT le projet Android et la configuration GitHub Actions.
Le logiciel Desktop EXE original n'est pas modifie.

1. Creer un repository GitHub PRIVE.
2. Sur GitHub, deposer LE CONTENU de cette archive a la racine du repository,
   en conservant les dossiers android/ et .github/workflows/ (dossier cache .github).
   Pour conserver correctement .github, le plus fiable est d'utiliser Git local ou
   l'upload via un ordinateur. Ne pas envoyer l'archive ZIP sans l'extraire.
3. Sur GitHub, ouvrir Actions > Compiler APK Android Rizerie Service Pro V2.5.
4. Cliquer Run workflow > Run workflow.
5. Consulter les logs de compilation. Si succes, ouvrir l'execution et telecharger
   l'artifact Rizerie-Service-Pro-V2-5-APK-Debug (archive ZIP contenant app-debug.apk).
6. Extraire app-debug.apk et tester sur un appareil Android.

IMPORTANT:
- APK DEBUG pour tests uniquement, pas une publication Play Store.
- Le build GitHub n'a pas ete execute ni valide ici.
- La synchronisation est toujours BETA : sauvegarder toutes les donnees PC.
- Ne jamais uploader des donnees de production, mots de passe ou fichiers .rpsync secrets.
- Le code contient des sources originales V2.5 ; aucun correctif metier n'est ajoute.
